# Next gate: review and formalize the two frozen follow-on certificates

## Objective

Formalize the exact finite constructions in `certificates/C11_d201.json` and
`certificates/C11_d210.json`, without changing their integers, tables,
coordinate ordering, child ordering, or DAG semantics. R3 is the accepted
ancestor, not a Lean certificate for these changed objects.

First run both normal and optimized standard-library replays:

```sh
python3 -B VERIFY.py --self-test --manifest
python3 -O -B VERIFY.py --self-test --manifest
```

Independently reconstruct the product-set induction and exact arithmetic.
Inspect all differences as new constructions rather than importing R3's final
capacity bound as a premise for the improved claims.

## Pins and proof chain

Use Lean 4.32.2, BPZ commit
`aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65`, and its pinned Mathlib commit
`905b95818eb32af7874a58b427f50c1711a5e96c` and transitive manifest. The R3
archive contains the working full-chain proof and audit/build harness repairs.

Create separate namespaces and modules for the 201- and 210-dimensional
objects. Express each distinct literal table as an admissible `Subst`, each
DAG node through `Realisation.multiSubst`, and the root through the existing
terminal code/product-set interfaces. Retain an EXPLICIT final set, prove its
exact cardinality, prove independence, flatten to Mathlib's
`SimpleGraph.cycleGraph 11` at the stated dimension, and derive the real-root
and decimal capacity bounds.

The new base-block exponents are 67 and 70. They are not 69. Reused nodes occur
in separate coordinate blocks each time they are used; dimension is the
unrolled occurrence count times three.

Required numerical comparisons are N201^207 > NR3^201 and
N210^207 > NR3^210. Merely proving that one new INTEGER is larger than NR3 is
wrong when dimensions differ. Include an explicit strict real-root comparison
with the full NR3, not just its displayed decimal.

## Evidence and negative controls

Build the frozen BPZ C11 baseline first; build both new complete modules; print
fully explicit scope assertions and actual axiom dependencies. In Lean 4.32.2,
native checks generate separate closed Boolean-equality axioms: inspect their
actual types, not just names, and disclose native compiler/runtime trust.
Reject sorryAx and unapproved new axioms.

For each new code, demonstrate an intended failure for a wrong-cardinality
claim N+1 and for insertion of a conflicting terminal block such as BBB.
Require the failures to be mathematical, not import/syntax accidents.

Record toolchain/dependency identities, command exit codes, complete logs,
source/compiled artifact hashes, and clean-extraction replay. Check both
working-tree and staged/index cleanliness of dependencies (`git diff
--exit-code` and `git diff --cached --exit-code`) before and after building.

The previous R3 mathematical source compiled unchanged; that success does not
guarantee these larger generated certificates will compile without elaboration
repairs. Do not weaken theorem scope or modify a finite certificate to fix an
elaboration issue. Preserve the submitted R3 release unchanged. No remote
publication or upstream write is requested by this handoff.
