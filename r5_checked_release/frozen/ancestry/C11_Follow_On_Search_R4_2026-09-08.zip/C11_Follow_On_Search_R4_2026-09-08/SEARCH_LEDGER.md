# Bounded search ledger

This ledger describes executed experiments, not an exhaustive classification.
All new positive claims are determined by the final exact certificates and
VERIFY.py; floating-point search scores are not acceptance evidence.

## Frozen start

The unchanged R3 archive has SHA-256
`9ac3006b54d5c449db357819d88ea507b66778923c61c54623d72d905517a357`.
Its release verifier passed (272 recorded manifest entries, 193 native-axiom
inspections in the delivered build evidence). Lean was not rerun here.

The new finite verifier separately reconstructed the BPZ and R3 root integers
from their complete recurrences as positive controls.

## Successful search progression

1. **Asymmetric schedules.** Independently varied the chain lengths and table
   choices in the left and right branches, rather than forcing the same p11
   construction to serve both roles. Integer parameters were proposed with
   differential evolution; every retained certificate was evaluated using
   integers. This produced an initial dimension-204 improvement.
2. **Table symmetries.** Tested literal BPZ tables, R3's row hybrid, coordinate
   permutations, and the separation-preserving reflection A<->D, H<->V.
   The output family can be reflected as well as each input. New tables are
   checked directly; their validity is never inferred merely from a label.
3. **Coordinate-block reallocation.** Deleted a binary/base step in one
   occurrence and inserted a binary/base step elsewhere, preserving the
   total dimension. These coordinated moves escaped the single-node optimum
   and yielded a dimension-201 certificate above R3.
4. **Binary-to-ternary fusion.** Replaced a parent binary step and one binary
   child by a directly optimized ternary table on the same three coordinate
   blocks. No extra coordinates are consumed. This led to the final retained
   roots 5.295493012564320 (201) and 5.295494464537079 (210).

The final certificates are the last saved `fusion_d201.json` and
`fusion_d210.json` objects, stripped of exploratory metadata and augmented
with exact decimal brackets. Full intermediate graphs and logs are retained
under search/. No larger seed or new base auxiliary set was adopted.

## Other executed experiments

- The terminal weighted independent-set MILP at the initial dimension-204
  schedule returned the same 19-word terminal code. Its floating-point
  optimality message is retained as solver output, NOT an independently
  certified optimization theorem.
- Two full-substitution MILP launches were terminated by execution timeouts.
  Neither supplied a final solver verdict or an adopted candidate. The
  retained log contains the last start marker only. No UNSAT or impossibility
  conclusion is drawn from either termination.
- One-/two-insertion table trades and iterated greedy perturbations at that
  early schedule found no improvement. These were bounded neighborhoods.
- Twelve valid binary and 123 valid ternary row hybrids were enumerated from
  the untransformed published row catalog (with empty O). Testing their
  symmetry extensions at a later incumbent did not improve that incumbent.
  This is not enumeration of all admissible tables.
- Flexible choices among the original main seed's six private alternatives,
  across 127,776 labelled auxiliary symmetry images, yielded only the original
  (145,142,3,3,3,3,3) profile in the tested >=3-port class. Only three images had
  at least three individually clean pairs; 12 oriented systems passed.
- Neutral single-word exchanges generated 30,001 states from I and 30,000 from
  X before the stated state caps. The search was NOT exhausted. Larger numbers
  of private alternatives partly came from repeated parents, not more usable
  ports. Two selected high-private-neighbor seeds, paired against four
  auxiliary seed orbits (511,104 labelled images), yielded no accepted new
  base system in the tested class.
- Twelve differential-evolution runs using the published four-letter terminal
  codes and the specified chain/ternary shapes did not beat R3. Their best
  reported root was approximately 5.2953518065, in dimension 192.

The exploratory four-letter table transcription initially failed its own
admissibility test because of transcription errors; the errors were corrected
against the pinned source before those searches ran. No failing table was
used in an accepted certificate. The final checkers validate literal tables
without relying on those transcriptions being an exact match to the source.

## Stop boundary

The search stopped with two positive finite certificates. It did not prove
that dimension 198 or any smaller dimension cannot beat R3, that dimension
201 is minimal, or that 5.295494464537079 is best within the framework.
The retained dimension-198 local incumbent was below R3. No queue submission,
repository push, upstream author contact, or new Lean build was performed.
