# C11 follow-on: a shorter exponent and a stronger root

Date: 8 September 2026. This is a new exploratory branch, not a replacement or
reseal of the submitted R3 construction.

## Results

| Object | Dimension | Exact certified truncation of the constructed root |
|---|---:|---:|
| Frozen BPZ | 207 | 5.295492315784620 |
| Accepted R3 | 207 | 5.295492477500681 |
| New shorter-exponent certificate | **201** | **5.295493012564320** |
| New stronger-root certificate | **210** | **5.295494464537079** |

Both new certificates pass the separately written standard-library finite
checker. Their Cartesian-product justification is in PROOF.md. Neither has
been compiled in Lean or independently reviewed by another reviewer. Neither
is asserted to be a worldwide record or an optimal exponent.

The original 148-word main and auxiliary sets, the selected three ports, and
the seven-letter separation system are unchanged. All changes concern the
recursive assembly: role-specific branches, table choices and symmetries,
base-block reallocation, and fusion of two binary steps into a ternary step.

## Replay

From an extracted copy, with Python 3.10 or newer:

```sh
python3 -B VERIFY.py --self-test --manifest
python3 -O -B VERIFY.py --self-test --manifest
```

The expected controlling marker is
`PASS_C11_FOLLOW_ON_EXACT_FINITE_CHECKS`. This is not a Lean-build marker.
The checker uses only the Python standard library and does not write files.
A manifest is an integrity record, not an authenticity signature.

## Reader path

* `PROOF.md`: theorem scope, Cartesian-product induction, exact integers.
* `certificates/`: two complete DAG certificates and all used literal tables.
* `evidence/VERIFICATION_NORMAL.json`: full node weights and check results.
* `SEARCH_LEDGER.md`: bounded experiments, unsuccessful attempts, limitations.
* `CODEX_HANDOFF.md`: precise next formalization/review gate.
* `ancestry/`: unchanged R3 archive and receipt review.

`search/` holds exploratory scripts and logs. Search uses floating-point
heuristics; acceptance does not. These scripts require NumPy/SciPy/Numba and
may write into their directory: run them only in a working copy, never in the
sealed release. The 60,001 large, regenerable neutral-seed states are not
retained; their generator and summary are. Solver timeouts are not negative
mathematical results.

The shorter certificate reduces the number of coordinates by 6/207, about
2.90%, but has more distinct construction nodes than R3. No faster Lean
compilation or smaller certificate-size claim is made. The stronger-root
certificate uses three more coordinates than R3. It increases the root by
about 0.000001987036399 over R3; its total improvement over the original BPZ
root is about 13.29 times the original R3 improvement. These remain modest
absolute improvements.

The frozen historical R3 candidate JSON still carries its original pre-Lean
metadata. It is preserved as historical input; the parent R3 release and its
receipt govern that candidate's later Lean status. No such status transfers
to the new certificates.
