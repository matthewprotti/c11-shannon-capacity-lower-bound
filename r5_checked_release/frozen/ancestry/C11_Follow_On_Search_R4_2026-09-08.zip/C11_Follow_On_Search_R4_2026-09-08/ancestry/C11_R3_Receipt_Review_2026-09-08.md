# C11 R3 receipt review — 8 September 2026

## Disposition

**ACCEPT THE RECORDED PINNED LEAN FORMALIZATION GATE**, with the disclosed native-evaluation and pinned dependency-cache trust boundary.

The supplied R3 evidence supports the existence of the explicit independent set `ShannonBounds.C11AuxiliaryTrade.code207` in the 207th strong power of `SimpleGraph.cycleGraph 11`, with exactly the frozen cardinality N1, the lower bound

\[
\Theta(C_{11})\ge 5.295492477500681,
\]

and strict improvement of the constructed 207th root over the full frozen BPZ integer at commit `aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65`.

This receipt is an automated examination of delivered source, build artifacts, transcripts and independent finite replay. **No fresh Lean compilation was performed in this receiving runtime.** The successful Lean compilation is the recorded Codex/macOS run in R3. Hash checks establish consistency and preservation, not cryptographic authentication of the machine that generated the evidence. No new mathematical defect or theorem-scope weakening was found in this receipt review.

## Received release identity

File: `C11_Lean_Checked_R3_2026-09-08.zip`

SHA-256:

```text
9ac3006b54d5c449db357819d88ea507b66778923c61c54623d72d905517a357
```

The R3 archive was left unchanged. Its 272 manifest entries, exact file inventory, 71 clean-run command-log hashes, and 121 retained compiled-artifact hashes passed independently written receipt checks. The two principal compiled artifacts also match the successful gate report. The top-level build report is identical to the clean-run build report.

## Source and input preservation

Both ancestor archives match the independently available prior uploads, not merely R3's own declared hashes. The mathematical module's SHA-256 is

```text
476be3b0c9cffacf14e35da7ebcea09f3d72ba0e0159e641efcc11e327393920
```

The module, candidate, frozen inputs, upstream lock and R1 ancestor are unchanged from R2. The exact finite-set, decimal-capacity and strict-root scope aliases are unchanged except for the added full-name pretty-printing option. The only six changed derived-source files are the manifest, build runner, source checker, harness tests, scope-audit printing and native-audit printing. The actual diff was read; it does not alter a theorem statement or construction proof.

Historical R2 comments saying the source was unbuilt, and older frozen certificate scope descriptions, are retained authoring history. R3's top-level status and actual build evidence supersede their historical status; there is no reason to edit frozen mathematical inputs just to refresh those descriptions.

## Recorded Lean evidence

The baseline and candidate logs both end in successful build completion. The source supplies the actual finite set, derives its cardinality through `card_multiCodeSet` and injective graph-isomorphism images, proves independence, and derives the capacity theorem from that same set. The compiled scope aliases bind the graph, exponent 207 and both full integer literals. They introduce no assumed independence, assumed cardinality or extra mathematical hypothesis.

The recorded compiler is Lean 4.32.2 at commit `f3b06c705e6c85f5314019d5d3baab0fec5b580c`. The reported Mathlib revision is `905b95818eb32af7874a58b427f50c1711a5e96c`. All nine recorded dependency Git HEADs agree before and after the run. See the dependency-index qualification below concerning what the tracked-source cleanliness checks establish.

The clean run rebuilds BPZ and the candidate in a fresh BPZ checkout. It reuses pinned dependency cache artifacts; it is not a source rebuild of Lean or all of Mathlib.

## Axiom evidence

The raw `#print axioms` transcript was parsed separately from the supplied parser, and its results agree with the recorded report. Across 13 audited declarations there are 193 distinct native-evaluation dependencies. The 193 generated environment-inspection commands, unique success markers and printed types correspond exactly to that union.

| Statement | Native dependencies |
|---|---:|
| Exact finite-set scope alias | 184 |
| Final decimal-capacity scope alias | 185 |
| Strict comparison of full constructed roots | 1 |
| Union across all 13 audited declarations | 193 |

These counts are not additive. “193” refers to this audited dependency union, not every native computation anywhere in all imported modules.

The inspected audit command checks each native declaration's existence, axiom declaration kind, non-unsafe status and closed Boolean-equality-to-true type. No `sorryAx` or unapproved additional axiom appears in the reported dependencies. The standard dependencies are `propext`, `Classical.choice` and `Quot.sound` where used.

The shape check is not an independent kernel recomputation that each Boolean equals true. The native compiler/runtime evaluates those expressions and supplies their equality axioms. Appropriate wording is **Lean-checked with disclosed native-evaluation trust**, not axiom-free or kernel-only finite-arithmetic verification.

## Negative controls

The exact log messages, probe sources and return codes were read and cross-checked. Both controls returned exit code 1 after the positive builds and audits had succeeded.

The wrong-cardinality probe attempts to use the proof of `code207.card = N1` as a proof of `code207.card = N1 + 1`. Lean rejects the exact type mismatch. The forbidden-block probe reinserts `ADA` into the N row and asks native evaluation to establish the required within-family separation. Lean reports that the proposition evaluates to false. Neither recorded failure is an import, syntax or missing-identifier failure.

## Checks actually executed in this receiving runtime

The supplied release verifier passed normally and under Python `-O`, checking 272 manifest entries. The derived source checks passed in both modes. All 19 supplied Python harness tests passed in both modes. These commands did not change R3 file contents, filenames or modification times.

The preserved R1 release verifier also passed normally and under `-O`. The unchanged independently written finite reviewer passed with the physical six-dimensional `b2` expansion, including its reported 317,348 nonempty first-block queries. A separately written arithmetic traversal reproduced both full root cardinalities, the dimension, strict integer comparison and exact decimal bracket. The independent receipt checker passed normally and under `-O` with identical result JSON.

These local checks supplement the delivered Lean evidence; none is represented as a fresh Lean build.

## Nonblocking build-harness observation

The new dependency cleanliness helper runs `git diff --exit-code`, which checks working tree versus index. It does not additionally check staged/index changes against HEAD. This differs from the BPZ checkout itself, for which both working-tree and cached/index diff commands are recorded.

A local synthetic Git fixture reproduced the gap: after editing and staging a tracked file, HEAD remained unchanged and the current helper's diff check returned 0, while `git diff --cached --exit-code` returned 1. Add the latter command to each dependency check before and after a future replay.

There is **no evidence of such a staged modification in the submitted build**, and this is not a counterexample to the mathematical construction, an observed bad dependency, or a reason to relabel the recorded successful Lean compilation as unbuilt. It limits the stronger inference that the current helper exhaustively certifies all tracked dependency contents against HEAD. The disclosed dependency-cache trust boundary remains relevant. R3 was not patched or resealed during this receipt review.

## Claim boundary and next disposition

The frozen construction and formalization gate are accepted on the submitted evidence. Worldwide priority, optimality, an unrestricted two-sided extension theorem, peer-reviewed publication and a VibeMathed significance score are not established by this build.

Suggested public wording:

> Within the Buys–Polak–Zuiddam construction framework, a coordinated auxiliary-family trade yields an explicit independent set in \(C_{11}^{\boxtimes207}\) and the lower bound \(\Theta(C_{11})\ge5.295492477500681\), strictly improving the full certificate at the named frozen BPZ commit. The construction-to-capacity proof has been checked in Lean 4.32.2, with the native-evaluation and dependency-cache trust boundary disclosed.

The appropriate next external step is expert reproduction and novelty/attribution assessment of this unchanged result, not another optimization run presented as though correctness or significance were already interchangeable.
