# Finite construction proof: dimensions 201 and 210

## Claim and evidence boundary

Let C11 be the cycle on residues modulo 11, with adjacency when the difference
is 1 or 10. Let C11^d denote its d-fold strong power. The two supplied finite
certificates describe independent sets with the following cardinalities:

N201 =
```text
32002673683286069537407802496635290542708504485557757541357004314290758191808590819113831084345541929742202157575979409830403540320810360987701516
```

N210 =
```text
104801829423661587743253299322841646006536831006849180624356444952325998520513365767989569418211784335842097686417867068684116769869616301057472136612714
```

They imply:

- Theta(C11) >= 5.295493012564320, from dimension 201.
- Theta(C11) >= 5.295494464537079, from dimension 210.

The finite compatibility, complete cardinality recurrences, dimensions,
cross-power comparisons, and exact decimal brackets have passed VERIFY.py,
both normally and with Python optimization enabled. The product-set induction
below explains why the recurrence counts an independent set. This is not a
claim that the new declarations have passed Lean or external peer review.

## Fixed base realization

The base graph is C11^3, with a word (x0,x1,x2) encoded as
x0 + 11*x1 + 121*x2. Equality is included in the confusability relation:

u conflicts with v iff, in every coordinate, u-v is 0, 1, or 10 modulo 11.

The two 148-word lists I and X and the private pairs are literally those in
FROZEN_INPUTS.json. Their frozen SHA-256 is
`bc3f401480f2b9a878ad24faa1d98c1ad848755a0537ceff0043f12f67bf7c26`.

Write P for the three parents and Q for their alternatives. Partition X into
A (words touching P), D (words touching Q), and N (words touching neither).
The checker verifies that A and D are disjoint. Define the seven families by
B=I\P, N as just defined, A, D, O=P, H=Q, V=P. Their sizes in order BNADOHV are
(145,142,3,3,3,3,3).

Every family is independent. The following unordered pairs of families are
separated, meaning no word in one conflicts with any word in the other:

BO, BH, BV, NA, ND, NO, NH, NV, AD, AH, DV.

These claims are checked against the literal coordinate definition, not
against supplied arithmetic profiles. The two seed checks examine 21,756
unordered pairs in total. Families are NOT assumed globally disjoint. In
particular O and V coincide in the base realization.

## Substitution lemma (the existing BPZ framework)

Suppose coordinate block i carries seven independent families P_i(a) in
C11^(d_i), with the stated separation guarantees. A word w of q letters
denotes the Cartesian product of P_i(w_i), with coordinates concatenated.
This product is independent in C11^(sum d_i). Indeed, two different tuples
in it differ in some block; independence in that block rules out overall
confusability.

Two symbolic words u,v are separated when at least one coordinate i has a
designated separation pair u_i,v_i. Their Cartesian products are then
mutually nonconfusable AND disjoint: a common tuple would violate separation
because equality is included in conflict.

For each output letter a, a substitution table T(a) lists pairwise separated
words. The union of their Cartesian products is therefore independent, and
its cardinality is exactly

    W_out(a) = sum over w in T(a) of product over i of W_i(w_i).

For every designated output pair a,b, the table also requires every word of
T(a) to be separated from every word of T(b). The resulting seven families
thus realize the same separation system and may be used recursively. Overlap
between unrelated output families causes no counting problem: counting takes
place within a row, where disjointness has been proved.

A terminal table is a single pairwise separated word list. The same argument
gives an independent set whose cardinality is the corresponding sum of
products. Heterogeneous input dimensions add, rather than multiply.

This is not claimed as a new composition theorem. It is the finite
separation/substitution framework of Buys, Polak and Zuiddam. The contribution
of this branch is the new choice and arrangement of its valid finite pieces.

## Applying the lemma to the certificates

Each certificate includes every used table as literal words and its entire
construction DAG in topological order. The checker verifies every within-row
and prescribed cross-row separation, all child references, every integer
weight, the root's terminal status, and the absence of unused nodes/tables.
All leaves are the fixed base realization. A reused DAG node supplies a copy
of its families in a NEW coordinate block at each occurrence; coordinate
cost is counted by occurrences, not by the number of unique DAG nodes.

For dimension 201, there are 67 base-block occurrences, 38 distinct DAG
nodes, and 14 distinct tables. The used tables require 7,387 within/cross
symbolic pair checks in total.

For dimension 210, there are 70 base-block occurrences, 40 distinct DAG
nodes, and 13 distinct tables. The used tables require 7,303 such pair checks.

Induction over the DAG, using the substitution lemma, proves that the root
sets are independent and have the exact integers N201 and N210 above. The
checker reports all intermediate profiles and dimensions in
`evidence/VERIFICATION_NORMAL.json`.

## Exact comparison and decimal statements

Let NR3 be the full frozen R3 cardinality:

```text
705692619930489413584189552943991443716392885026759451863953624242911159057444856108323516589876967077721069272782760798453832061060020786354479288616
```

The checker establishes the STRICT INTEGER inequalities

    N201^207 > NR3^201,
    N210^207 > NR3^210,
    N210^201 > N201^210.

Taking the corresponding positive roots proves that both new constructions
improve the full R3 constructed root, and that the dimension-210 root exceeds
the dimension-201 root. No rounded baseline is used. Analogous comparisons
against the original BPZ integer also pass.

With D=10^15, the exact decimal brackets are:

    5295493012564320^201 <= N201 * D^201 < 5295493012564321^201,
    5295494464537079^210 <= N210 * D^210 < 5295494464537080^210.

Thus the displayed lower decimals are valid lower bounds. The upper endpoints
bound these CONSTRUCTED ROOTS, not Shannon capacity itself. By the definition
of Shannon capacity as the supremum of independence-number roots, each
constructed independent set supplies its respective capacity lower bound.

## Attribution and limits

The unchanged seeds, separation framework, tables underlying the search, and
baseline schedule are due to BPZ and the earlier authors credited by BPZ.
The source is `spectra-research/shannon-capacity-lean`, commit
`aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65`; relevant files are
`BaseC11Data.lean`, `PortRealisation.lean`, `Layered.lean`,
`Substitutions.lean`, `TerminalCodes.lean`, `CertC11.lean`, and
`CapCertC11.lean`. R3 supplied the accepted local row hybrid.

Search on this branch was AI-assisted in this conversation; the new finite
checker was written separately from the search routines. That is not an
external independent reviewer. Neither the minimum possible dimension nor a
best achievable root has been proved. This does not resolve the general
two-sided extension problem, establish worldwide priority, or imply a
particular VibeMathed significance score.
