/-
UNBUILT FORMALIZATION FRAGMENT — 8 September 2026.
This file is not a completed Lean proof of the new capacity bound.
It isolates the row hybrid and exact integer inequalities for review.
Based on BPZ's Apache-2.0 substitution library at the pinned commit.
-/
import ShannonBounds.Substitutions
import ShannonBounds.TerminalCodes

namespace ShannonBounds
namespace C11AuxiliaryTrade
open SimpleGraph Letter
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option exponentiation.threshold 20000

/-- Use T3d's N,A rows and T3c's other rows. -/
def T3mix : Letter → Finset (Fin 3 → Letter)
  | .N => Substitutions.T3d .N
  | .A => Substitutions.T3d .A
  | a => Substitutions.T3c a

/-- Full finite admissibility, to be checked in the pinned Lean environment. -/
def S3mix : Subst Letter Letter.sep 3 :=
  ⟨T3mix, by native_decide, by native_decide⟩

def N0 : Nat := 705688158939417766083006128695703821080101605304173623991920300506716846627203440324635068341693109509608786929844839653207121849017872676157797788816
def N1 : Nat := 705692619930489413584189552943991443716392885026759451863953624242911159057444856108323516589876967077721069272782760798453832061060020786354479288616

theorem strictly_larger : N0 < N1 := by native_decide

theorem decimal_lower :
    5295492477500681 ^ 207 ≤ N1 * (1000000000000000 : Nat) ^ 207 := by
  native_decide

theorem decimal_upper :
    N1 * (1000000000000000 : Nat) ^ 207 < 5295492477500682 ^ 207 := by
  native_decide

-- Remaining obligation: replace Gg by S3mix at Rx27 only, prove the new
-- x27 weights and terminal cardinality, then derive the full capacity
-- theorem through BPZ's existing strong-power and capacity interface.
end C11AuxiliaryTrade
end ShannonBounds
