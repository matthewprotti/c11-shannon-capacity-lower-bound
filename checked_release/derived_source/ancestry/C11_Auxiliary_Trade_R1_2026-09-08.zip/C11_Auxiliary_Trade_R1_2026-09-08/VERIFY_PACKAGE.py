#!/usr/bin/env python3
"""Read-only R1 release verification, including unchanged supplied review code.

Integrity checks anchor the copied parent and review to their externally recorded
SHA-256 values. They do not turn a self-authored manifest into authentication.
The mathematical verifier remains separate from this packaging wrapper.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
PARENT = 'ancestry/C11_Auxiliary_Trade_Checkpoint_2026-09-08.zip'
PARENT_SHA = 'b62863f7cd1718024a94a52683dd2fd2e95725bc9531832d8b37585450fb5b66'
REVIEW = 'ancestry/C11_Adversarial_Review_2026-09-08.zip'
REVIEW_SHA = 'e983a2235be05eca8230eee2b2b951903c2cd605c1510efcb3fabe27ee7c0520'
PARENT_PREFIX = 'C11_Auxiliary_Trade_2026-09-08/'
REVIEW_PREFIX = 'C11_Adversarial_Review_2026-09-08/'
PRESERVED = ('CANDIDATE.json', 'FROZEN_INPUTS.json', 'PROOF.md', 'CandidateTrade.lean')

class ReleaseError(Exception):
    pass

def require(condition: bool, message: str) -> None:
    if not condition:
        raise ReleaseError(message)

def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()

def check_manifest() -> int:
    manifest = ROOT/'MANIFEST.sha256'
    require(manifest.is_file(), 'missing required release manifest')
    listed = set()
    for line in manifest.read_text().splitlines():
        value, name = line.split('  ', 1)
        p = PurePosixPath(name)
        require(not p.is_absolute() and '..' not in p.parts and name == p.as_posix(),
                'unsafe or noncanonical manifest path: '+name)
        require(name not in listed and name != 'MANIFEST.sha256', 'duplicate/self manifest entry')
        require(len(value) == 64 and set(value) <= set('0123456789abcdef'), 'bad manifest digest')
        target = ROOT/name
        require(target.is_file() and not target.is_symlink(), 'missing or symlink file: '+name)
        require(digest(target.read_bytes()) == value, 'manifest mismatch: '+name)
        listed.add(name)
    require(not any(p.is_symlink() for p in ROOT.rglob('*')), 'symlinks not supported')
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    require(listed == actual - {'MANIFEST.sha256'}, 'manifest file coverage mismatch')
    return len(listed)

def invoke(script: str, *args: str) -> dict:
    options = ['-O'] if sys.flags.optimize else []
    command = [sys.executable, *options, '-B', str(ROOT/script), *args]
    process = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
    require(process.returncode == 0, script+' failed: '+process.stderr)
    return json.loads(process.stdout)

def run() -> dict:
    count = check_manifest()
    for name, expected in ((PARENT, PARENT_SHA), (REVIEW, REVIEW_SHA)):
        require(digest((ROOT/name).read_bytes()) == expected, 'ancestral archive mismatch: '+name)
    lineage = json.loads((ROOT/'LINEAGE_LOCK.json').read_text())
    require(lineage['parent_archive'] == {'path': PARENT, 'sha256': PARENT_SHA}, 'parent lineage')
    require(lineage['received_review_archive'] == {'path': REVIEW, 'sha256': REVIEW_SHA}, 'review lineage')
    with zipfile.ZipFile(ROOT/PARENT) as archive:
        for name in PRESERVED:
            raw = (ROOT/name).read_bytes()
            require(raw == archive.read(PARENT_PREFIX+name), 'changed accepted input: '+name)
            require(digest(raw) == lineage['mathematical_files_preserved_byte_for_byte'][name],
                    'input lineage hash mismatch: '+name)
    with zipfile.ZipFile(ROOT/REVIEW) as archive:
        names = [i.filename for i in archive.infolist() if not i.is_dir()]
        require(len(names) == len(set(names)), 'duplicate received review member')
        expected = set()
        for name in names:
            require(name.startswith(REVIEW_PREFIX), 'review prefix mismatch')
            local = name[len(REVIEW_PREFIX):]
            expected.add(local)
            require((ROOT/'received_review'/local).read_bytes() == archive.read(name),
                    'changed received review file: '+local)
        actual = {p.relative_to(ROOT/'received_review').as_posix()
                  for p in (ROOT/'received_review').rglob('*') if p.is_file()}
        require(actual == expected, 'received review directory coverage mismatch')
    direct = invoke('VERIFY.py', '--self-test')
    require(direct['status'] == 'PASS_EXACT_C11_IMPROVEMENT', 'direct replay status')
    # This code is received, not newly authored for R1, and still checks the original ZIP.
    # Byte identity above transfers its mathematical input checks to the R1 inputs.
    independent = invoke('received_review/INDEPENDENT_REVIEW.py', str(ROOT/PARENT), '--expand-b2')
    require(independent['status'] == 'PASS_INDEPENDENT_FINITE_REPLAY', 'independent replay status')
    for field in ('N0', 'N1', 'delta'):
        require(direct[field] == independent[field], 'independent result mismatch: '+field)
    require(direct['dimension'] == independent['dimensions']['root'] == 207, 'physical dimension')
    mutations = invoke('received_review/ADDITIONAL_MUTATIONS.py', str(ROOT))
    tests = mutations['tests']
    require(len(tests) == 10, 'unexpected reviewer regression test count')
    require(all(t['outcome'] == 'REJECTED' and t['exception'] == 'CheckFailed' for t in tests),
            'reviewer mutation not rejected by explicit validation')
    return {
        'status': 'PASS_C11_R1_RELEASE',
        'manifest_files_checked': count,
        'parent_sha256': PARENT_SHA,
        'received_review_sha256': REVIEW_SHA,
        'accepted_files_preserved_byte_for_byte': list(PRESERVED),
        'finite_replay': direct['status'],
        'supplied_independent_reviewer_replay': independent['status'],
        'independent_review_target': 'ORIGINAL_PARENT_ZIP; mathematical inputs unchanged in R1',
        'physical_b2_audit': independent['physical_b2_audit'],
        'N0': direct['N0'], 'N1': direct['N1'], 'delta': direct['delta'], 'dimension': 207,
        'root_interval_from_independent_replay': independent['exact_root_bracket'],
        'negative_controls_rejected': len(direct['negative_controls_rejected']),
        'positive_controls_passed': direct['positive_controls_passed'],
        'reviewer_mutations_rejected': len(tests),
        'metadata_repair': 'F3_REPRODUCED_ON_PARENT_AND_REJECTED_ON_R1',
        'new_independent_review_of_R1_patch': 'NOT_PERFORMED',
        'end_to_end_lean_build': 'NOT_RUN',
        'worldwide_priority_clearance': 'INCOMPLETE',
        'new_literature_or_priority_scan_this_release': False,
    }

if __name__ == '__main__':
    try:
        print(json.dumps(run(), indent=2, sort_keys=True))
    except (ReleaseError, OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
        print('FAIL: '+str(error), file=sys.stderr)
        raise SystemExit(1)
