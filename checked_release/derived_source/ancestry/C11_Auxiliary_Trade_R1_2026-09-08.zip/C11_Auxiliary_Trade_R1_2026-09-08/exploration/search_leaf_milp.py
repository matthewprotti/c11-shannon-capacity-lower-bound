from core import *
from leaf_roles import LEAVES
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix,vstack,csr_matrix
import time,warnings
start=time.monotonic();rows=[];cols=[]
for row,x in enumerate(VTX):
 for off in itertools.product([0,1],repeat=3):
  rows.append(row);cols.append(int(((x+off)%11)@np.array([1,11,121])))
A=coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(1331,1331)).tocsr();lo=[-np.inf]*1331;hi=[1.]*1331
extra=[np.ones(1331)];lo.append(-np.inf);hi.append(148.)
for j in range(3):
 for k in range(11):
  extra.append(((VTX[:,j]==k)|(VTX[:,j]==(k+1)%11)).astype(float));lo.append(-np.inf);hi.append(27.)
# Bounded local class: retain at least 136 words of the supplied 148-word X.
r=np.zeros(1331);r[X]=1;extra.append(r);lo.append(136.);hi.append(np.inf)
A=vstack([A,csr_matrix(np.array(extra))],format='csc')
ub=(~(NP&NQ)).astype(float);bounds=Bounds(np.zeros(1331),ub)
cons=LinearConstraint(A,np.array(lo),np.array(hi));records=[]
for leaf in [0,28,49,55]:
 grad=LEAVES[leaf]['gradient'];coef=np.where(NP,float(grad[2]/grad[1]),np.where(NQ,float(grad[3]/grad[1]),1.))
 t=time.monotonic()
 with warnings.catch_warnings():
  warnings.simplefilter('ignore')
  ans=milp(-coef,integrality=np.ones(1331,dtype=np.int8),bounds=bounds,constraints=cons,options={'time_limit':30.,'mip_rel_gap':0.,'threads':1})
 rec=dict(leaf=leaf,status=int(ans.status),message=ans.message,elapsed_seconds=time.monotonic()-t,search_coefficients=[1.,float(grad[2]/grad[1]),float(grad[3]/grad[1])])
 if ans.x is not None:
  xx=list(map(int,np.where(ans.x>.5)[0]));w=profile(xx)
  assert indep(xx) and w is not None
  assert len(set(xx)&set(X))>=136 and len(xx)<=148
  delta=sum(c*(v-u)for c,v,u in zip(grad,w,profile()))
  rec.update(X=xx,profile=list(w),exact_delta=str(delta),candidate_N=str(M0+delta),improves=delta>0,removed_from_X=len(set(X)-set(xx)))
 print('LEAF_SEARCH', {k:v for k,v in rec.items()if k not in ['X','candidate_N','exact_delta']},flush=True)
 records.append(rec)
 (Path(__file__).parent/'leaf_milp_results.json').write_text(json.dumps(dict(local_retention=136,time_limit_each=30,records=records,elapsed_seconds=time.monotonic()-start),indent=2)+'\n')
print('TOTAL_SECONDS',time.monotonic()-start)
