from core import *
from scipy.ndimage import maximum_filter, convolve1d
import time,collections
start=time.monotonic();fs=dict(np.load(Path(__file__).parent/'b2_families.npz'))
N=11**6;shape=(11,)*6;pows=np.array([11**i for i in range(6)],dtype=np.int64)
offsets=np.array(list(itertools.product([-1,0,1],repeat=6)),dtype=np.int16)
def digits(v):return (np.array(v)[...,None]//pows)%11
def neighborhood(v):return ((digits(v)+offsets)%11)@pows
def conf(u,v):
 d=(digits(u)-digits(v))%11
 return np.all((d==0)|(d==1)|(d==10),axis=-1)
records=[];improvements=[]
for a in 'BNADHV':
 j=IDX[a];sep_mask=np.zeros(N,dtype=np.uint8)
 for k,b in enumerate(ABC):
  if SEP[j,k]:sep_mask[fs[b]]=1
 forbidden=maximum_filter(sep_mask.reshape(shape),size=3,mode='wrap').ravel()
 own=np.zeros(N,dtype=np.uint16);own[fs[a]]=1;counts=own.reshape(shape)
 for axis in range(6):counts=convolve1d(counts,np.ones(3,dtype=np.uint16),axis=axis,mode='wrap')
 counts=counts.ravel();orig=set(map(int,fs[a]));allowed=(forbidden==0)
 cand=np.where(allowed & (counts<=2) & (own==0))[0]
 groups=collections.defaultdict(list)
 for v in cand:
  neigh=neighborhood(int(v));block=tuple(sorted(map(int,neigh[own[neigh]!=0])))
  assert len(block)==int(counts[v])
  groups[block].append(int(v))
 sizes=collections.Counter(int(counts[v])for v in cand)
 print('EXCHANGE_CLASS',a,'allowed',int(allowed.sum()),'count1/2',sizes,'groups',len(groups),flush=True)
 found=None;tested1=0;tested2=0
 for block,vs in groups.items():
  if len(block)==1:
   for p,q in itertools.combinations(vs,2):
    tested1+=1
    if not conf(p,q):found=dict(family=a,remove=list(block),add=[p,q]);break
   if found:break
 if not found:
  for block,vs0 in groups.items():
   if len(block)!=2:continue
   vs=vs0+groups.get((block[0],),[])+groups.get((block[1],),[])
   # Include deleted originals if useful; not needed for a minimal positive exchange.
   for p,q,r in itertools.combinations(vs,3):
    tested2+=1
    if not conf(p,q) and not conf(p,r) and not conf(q,r):
     found=dict(family=a,remove=list(block),add=[p,q,r]);break
   if found:break
 rec=dict(family=a,allowed_vertices=int(allowed.sum()),eligible_by_blocker_count=dict(sizes),blocker_groups=len(groups),one_to_two_trials=tested1,two_to_three_trials=tested2,improvement=found)
 records.append(rec)
 if found:
  improvements.append(found);print('FOUND',found,flush=True)
 np.savez_compressed(Path(__file__).parent/f'exchange_{a}.npz',candidates=cand,blocker_counts=counts[cand])
 print('TIME',time.monotonic()-start,flush=True)
(Path(__file__).parent/'exchange_results.json').write_text(json.dumps(dict(records=records,improvements=improvements,elapsed_seconds=time.monotonic()-start),indent=2)+'\n')
