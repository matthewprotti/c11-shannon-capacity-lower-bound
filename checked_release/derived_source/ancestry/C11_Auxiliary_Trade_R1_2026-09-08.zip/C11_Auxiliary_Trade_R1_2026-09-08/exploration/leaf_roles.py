from core import *
NODE={n['name']:n for n in DATA['nodes']}
LEAVES=[]
def make(name):
 n=NODE[name]
 if n['kind']=='base':
  t=dict(name=name,kind='base',w=profile(),leaf=len(LEAVES));LEAVES.append(t);return t
 children=[make(c)for c in n['children']]
 return dict(name=name,kind=n['kind'],children=children,w=evaluate(TABLES[n['kind']],[c['w']for c in children]))
def back(t,grad):
 if t['kind']=='base':t['gradient']=grad;return
 tab=TABLES[t['kind']];ch=t['children'];gs=[[0]*7 for c in ch]
 sets=[(1,tab)]if isinstance(tab,list)else[(grad[IDX[a]],tab[a])for a in ABC]
 for upstream,words in sets:
  for word in words:
   for j,a in enumerate(word):
    gs[j][IDX[a]]+=upstream*math.prod(ch[k]['w'][IDX[b]]for k,b in enumerate(word)if k!=j)
 for c,g in zip(ch,gs):back(c,g)
ROOT=make('root');assert ROOT['w']==M0;back(ROOT,None)
if __name__=='__main__':
 roles={}
 for l in LEAVES:
  g=l['gradient'];abc=(g[1],g[2],g[3]);div=math.gcd(*abc);s=tuple(x//div for x in abc)
  roles.setdefault(s,[]).append(l['leaf'])
 print('LEAVES',len(LEAVES),'unique aux objectives',len(roles))
 for k,v in roles.items():print('ROLE',v,'ratios',float(k[1]/k[0]),float(k[2]/k[0]))
 (Path(__file__).parent/'leaf_roles.json').write_text(json.dumps(dict(leaves=[dict(index=l['leaf'],gradient=[str(g)for g in l['gradient']])for l in LEAVES],unique_objectives=len(roles)),indent=2)+'\n')
 own=set(X);nc=CONFLICT[:,X].sum(axis=1)
 print('X private alternatives',[(v,int(np.array(X)[CONFLICT[v,X]][0]),bool(NP[v]),bool(NQ[v]))for v in range(1331)if v not in own and nc[v]==1])
