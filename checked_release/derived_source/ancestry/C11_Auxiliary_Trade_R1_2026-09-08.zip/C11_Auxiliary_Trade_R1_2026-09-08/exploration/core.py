import json,itertools,math
from pathlib import Path
import numpy as np
DATA=json.loads((Path(__file__).parent/'frozen_inputs.json').read_text())
ABC=DATA['alphabet']; IDX={x:i for i,x in enumerate(ABC)}
TABLES=DATA['tables']; M0=int(DATA['N0'])
SEP=np.zeros((7,7),dtype=bool)
for a,b in DATA['sep']:SEP[IDX[a],IDX[b]]=SEP[IDX[b],IDX[a]]=True
VTX=np.array(list(itertools.product(range(11),repeat=3)),dtype=np.int16)[:,::-1].copy()
DIFF=(VTX[:,None,:]-VTX[None,:,:])%11
CONFLICT=np.all((DIFF==0)|(DIFF==1)|(DIFF==10),axis=2)
I=DATA['I'];X=DATA['X'];P=[r for r,q in DATA['pairs']];Q=[q for r,q in DATA['pairs']]
NP=CONFLICT[:,P].any(axis=1);NQ=CONFLICT[:,Q].any(axis=1)

def indep(U):
 u=list(U)
 return len(u)==len(set(u)) and not np.triu(CONFLICT[np.ix_(u,u)],1).any()
def families(x=X,i=I,p=P,q=Q):
 np_=CONFLICT[:,p].any(axis=1);nq_=CONFLICT[:,q].any(axis=1)
 if any(np_[u] and nq_[u] for u in x):return None
 return [sorted(set(i)-set(p)),[u for u in x if not np_[u] and not nq_[u]], [u for u in x if np_[u]],[u for u in x if nq_[u]],list(p),list(q),list(p)]
def profile(x=X,i=I,p=P,q=Q):
 f=families(x,i,p,q)
 return tuple(map(len,f)) if f is not None else None
def wordsep(w,z,sep=SEP):return any(sep[IDX[a],IDX[b]] for a,b in zip(w,z))
def check_table(t):
 if isinstance(t,list):return all(wordsep(w,z) for w,z in itertools.combinations(t,2))
 return all(all(wordsep(w,z) for w,z in itertools.combinations(ws,2)) for ws in t.values()) and all(all(wordsep(w,z) for w in t[a] for z in t[b]) for a,b in itertools.combinations(ABC,2) if SEP[IDX[a],IDX[b]])
def evaluate(t,ws):
 def val(words):return sum(math.prod(w[IDX[a]] for w,a in zip(ws,s)) for s in words)
 return val(t) if isinstance(t,list) else tuple(val(t[a]) for a in ABC)
def baseline(w=None,replacement=None):
 w=profile() if w is None else w
 res={};dims={}
 for n in DATA['nodes']:
  name=n['name'];typ=n['kind']
  if typ=='base':res[name]=w;dims[name]=3
  else:
   ch=n['children'];res[name]=evaluate(TABLES[typ],[res[c] for c in ch]);dims[name]=sum(dims[c] for c in ch)
  if replacement and name in replacement:res[name]=replacement[name]
 return res,dims
if __name__=='__main__':
 assert indep(I) and indep(X)
 f=families()
 assert all(indep(x) for x in f)
 for a,b in itertools.combinations(range(7),2):
  if SEP[a,b]:assert not CONFLICT[np.ix_(f[a],f[b])].any(),(ABC[a],ABC[b])
 assert all(check_table(t) for t in TABLES.values())
 res,dims=baseline()
 assert res['g3']==(3056536,2867365,193005,181476,0,185310,189144),res['g3']
 assert res['root']==M0,(res['root'],M0)
 assert dims['root']==207
 print('BASELINE_REPRODUCED',res['root'],dims['root'])
 print('PROFILES',profile())
 print('PRIVATE_NEIGHBORS',[(int(v),int(np.array(I)[CONFLICT[v,I]][0])) for v in range(1331) if v not in I and CONFLICT[v,I].sum()==1])
 print('EXTRA_SEPARATIONS',[(ABC[a],ABC[b]) for a,b in itertools.combinations(range(7),2) if not SEP[a,b] and not CONFLICT[np.ix_(f[a],f[b])].any()])
 for label,U in [('I',I),('X',X)]:
  print(label,'LAYERS',[[sum(VTX[u,j]==z for u in U) for z in range(11)]for j in range(3)])
