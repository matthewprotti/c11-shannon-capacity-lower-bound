from core import *
import time,collections
start=time.monotonic();profiles={};valid=0;tested=0
best=(M0,None)
rows=[]
for seedname,seed in [('I',I),('X',X)]:
 for perm in itertools.permutations(range(3)):
  for signs in itertools.product([-1,1],repeat=3):
   xyz=(VTX[seed][:,perm]*signs)%11
   images=((xyz[None,:,:]+VTX[:,None,:])%11)@np.array([1,11,121])
   bp=NP[images];bq=NQ[images]
   ok=~(bp&bq).any(axis=1)
   for tr in np.where(ok)[0]:
    a=int(bp[tr].sum());d=int(bq[tr].sum());w=(145,148-a-d,a,d,3,3,3)
    valid+=1
    if w not in profiles:
     code=list(map(int,images[tr]));n=baseline(w)[0]['root']
     rec=dict(seed=seedname,permutation=list(perm),signs=list(signs),translation=list(map(int,VTX[tr])),X=code,profile=list(w),N=str(n))
     profiles[w]=rec
     if n>best[0]:best=(n,rec);print('IMPROVEMENT',w,str(n),flush=True)
   tested+=len(images)
print('ORBIT_RESULT',tested,valid,'distinct profiles',len(profiles),'elapsed',time.monotonic()-start)
print('PROFILES',sorted(profiles))
out=dict(status='IMPROVED_FROZEN_BASELINE' if best[1] else 'NO_IMPROVEMENT_IN_TESTED_ORBIT_CLASS',tested_labelled_images=tested,valid_images=valid,distinct_profiles=len(profiles),elapsed_seconds=time.monotonic()-start,profiles=list(profiles.values()))
(Path(__file__).parent/'orbit_results.json').write_text(json.dumps(out,indent=2)+'\n')
