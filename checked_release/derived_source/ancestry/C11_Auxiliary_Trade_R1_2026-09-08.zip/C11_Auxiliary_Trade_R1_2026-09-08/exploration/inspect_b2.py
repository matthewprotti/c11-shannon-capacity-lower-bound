from core import *
from scipy.ndimage import maximum_filter
import time
start=time.monotonic()
f=families();t=TABLES['T2b'];fs=[]
for a in ABC:
 arr=np.concatenate([ (np.array(f[IDX[s[0]]])[:,None]+1331*np.array(f[IDX[s[1]]])[None,:]).ravel() for s in t[a]]) if t[a] else np.array([],dtype=np.int64)
 assert len(arr)==len(set(arr))
 fs.append(arr.astype(np.int64))
N=11**6
candidates={}
for j,a in enumerate(ABC):
 mask=np.zeros(N,dtype=np.uint8)
 for k,b in enumerate(ABC):
  if j==k or SEP[j,k]:mask[fs[k]]=1
 forbidden=maximum_filter(mask.reshape((11,)*6),size=3,mode='wrap').ravel()
 cand=np.where(forbidden==0)[0]
 candidates[a]=list(map(int,cand))
 print('FAMILY',a,'size',len(fs[j]),'admissible additions',len(cand),'sample',cand[:12],flush=True)
np.savez_compressed(Path(__file__).parent/'b2_families.npz',**{a:fs[j]for j,a in enumerate(ABC)})
(Path(__file__).parent/'b2_candidates.json').write_text(json.dumps(dict(dimension=6,block_encoding='left+1331*right',candidates=candidates,elapsed_seconds=time.monotonic()-start),indent=2)+'\n')
print('Elapsed',time.monotonic()-start)
