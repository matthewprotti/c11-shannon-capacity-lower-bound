from core import *
from leaf_roles import ROOT
import time
START=time.monotonic(); LIMIT=75.
ALL=[]
def ad(t,grad):
 t['gradient']=grad;t['index']=len(ALL);ALL.append(t)
 if t['kind']=='base':return
 tab=TABLES[t['kind']];ch=t['children'];gs=[[0]*7 for c in ch]
 sets=[(1,tab)]if isinstance(tab,list)else[(grad[IDX[a]],tab[a])for a in ABC]
 for upstream,words in sets:
  for word in words:
   for j,a in enumerate(word):gs[j][IDX[a]]+=upstream*math.prod(ch[k]['w'][IDX[b]]for k,b in enumerate(word)if k!=j)
 for c,g in zip(ch,gs):ad(c,g)
ad(ROOT,None)
letters='BNADHV';lids=np.array([IDX[a]for a in letters]);structures={}
for arity in [2,3]:
 words=[''.join(w)for w in itertools.product(letters,repeat=arity)];wi=np.array([[IDX[a]for a in w]for w in words]);out=np.repeat(lids,len(words));wordsall=words*6;ww=np.tile(wi,(6,1))
 separated=np.any(SEP[ww[:,None,:],ww[None,:,:]],axis=2)
 needed=(out[:,None]==out[None,:])|SEP[out[:,None],out[None,:]]
 C=needed&~separated
 lookup={(ABC[o],w):j for j,(o,w)in enumerate(zip(out,wordsall))}
 structures[arity]=(out,wordsall,C,lookup)
results=[]
for t in ALL:
 if t['kind']not in ['T2b','T3c']:continue
 if time.monotonic()-START>LIMIT:break
 arity=len(t['children']);out,words,C,lookup=structures[arity]
 exact=[t['gradient'][o]*math.prod(ch['w'][IDX[a]]for ch,a in zip(t['children'],w))for o,w in zip(out,words)]
 norm=max(exact);w=np.array([v/norm for v in exact]);tab=TABLES[t['kind']]
 initial=set(lookup[(a,s)]for a in letters for s in tab[a]);S=set(initial)
 moves=[]
 for step in range(8):
  chosen=sorted(S);cw=w[chosen];block=C[:,chosen];cost=block@cw;gain=w-cost;gain[chosen]=-np.inf
  j=int(np.argmax(gain));new=[j];remove={s for s in S if C[j,s]}
  if gain[j]<=1e-16:
   shared=(block*cw)@block.T
   pgain=(w-cost)[:,None]+(w-cost)[None,:]+shared
   pgain[C]=-np.inf;pgain[chosen,:]=-np.inf;pgain[:,chosen]=-np.inf
   p,q=map(int,np.unravel_index(np.argmax(pgain),pgain.shape))
   if pgain[p,q]<=1e-16:break
   new=[p,q];remove={s for s in S if C[p,s]or C[q,s]}
  delta=sum(exact[j]for j in new)-sum(exact[j]for j in remove)
  if delta<=0:break
  S.difference_update(remove);S.update(new)
  moves.append(dict(add=[(ABC[out[j]],words[j])for j in new],remove=[(ABC[out[j]],words[j])for j in sorted(remove)],exact_gain=str(delta)))
 if S!=initial:
  newtab={a:[]for a in ABC}
  for j in sorted(S):newtab[ABC[out[j]]].append(words[j])
  assert check_table(newtab)
  newprofile=evaluate(newtab,[c['w']for c in t['children']])
  delta=sum(g*(b-a)for g,a,b in zip(t['gradient'],t['w'],newprofile))
  assert delta==sum(exact[j]for j in S)-sum(exact[j]for j in initial)>0
  rec=dict(node_index=t['index'],node_name=t['name'],table=newtab,original_profile=[str(x)for x in t['w']],new_profile=[str(x)for x in newprofile],exact_delta=str(delta),candidate_N=str(M0+delta),dimension=207,moves=moves)
  results.append(rec);print('FOUND_IMPROVED_TABLE',t['index'],t['name'],'moves',len(moves),'delta',str(delta),flush=True)
  # one verified positive witness is enough for this checkpoint
  break
 print('TESTED',t['index'],t['name'],'seconds',time.monotonic()-START,flush=True)
(Path(__file__).parent/'table_search_results.json').write_text(json.dumps(dict(results=results,elapsed_seconds=time.monotonic()-START),indent=2)+'\n')
