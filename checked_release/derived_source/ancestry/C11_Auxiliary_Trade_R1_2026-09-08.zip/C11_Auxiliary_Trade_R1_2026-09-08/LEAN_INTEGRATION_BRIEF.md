# Next gate: end-to-end Lean integration of the frozen C11 candidate

## Fixed scope

Use the upstream commit `aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65`, the toolchain specified there, and the unchanged `CANDIDATE.json` / `FROZEN_INPUTS.json` in this release. First run `python3 -B VERIFY_PACKAGE.py` and confirm `PASS_C11_R1_RELEASE`.

Do not optimize the construction, replace the seed, select a newer upstream baseline, or change the table/schedule during this gate. Preserve the original sources and this release. Add the proof in a derived checkout or separate module.

## Required proof connection

The included `CandidateTrade.lean` is an unbuilt fragment. It defines the N+A hybrid from BPZ's T3d and the remaining rows from T3c, plus inequalities about literal integers. Even a successful build of that file alone would not prove the capacity bound.

The deliverable must connect the actual construction to the literal N1:

1. Check the hybrid's within-family and cross-family admissibility using the pinned separation system. Do not assume the seven realized families are globally disjoint.
2. Instantiate the hybrid substitution at x27 only, on the unchanged ordered children h7, p11, h9. Prove the seven new weights. This node has 27 base blocks and physical dimension 81.
3. Use the unchanged terminal code K3a on the modified x27 and the unchanged x29 and b13. Its three child dimensions are 81, 87, and 39. Establish the exact union cardinality N1 through the realized-set/product/cardinality lemmas, not an unconnected arithmetic definition.
4. Derive the independent set in the actual 207th strong power of the 11-cycle through the pinned graph identification and flattening interfaces. Then obtain the new Shannon capacity lower bound and the exact root comparison with the frozen N0.

The candidate root's upper decimal endpoint is not an upper bound on Shannon capacity. Keep that distinction in formal theorem names and prose.

## Acceptance evidence

Supply a clean successful build transcript and a minimal reproducible module list in the pinned checkout. Inspect and record the final theorem's axioms; do not add assumptions for independence, admissibility, cardinality, or the desired capacity inequality. Report the proof's actual trusted base, including the role of native evaluation where used. Do not call the result end-to-end Lean verified merely because isolated native_decide arithmetic passed.

The final proof must depend on the constructed independent set of exactly the frozen N1 in dimension 207, with no sorry/admit or equivalent replacement of the missing mathematical connection. Attach a theorem-statement/scope check and hashes of the derived proof files.

If a build or environment fails, record the exact failure and preserve a NOT_COMPLETED status. Do not weaken the theorem, change the numbers, or promote the fragment to a full proof.

Priority clearance and significance assessment are outside this formalization gate.
