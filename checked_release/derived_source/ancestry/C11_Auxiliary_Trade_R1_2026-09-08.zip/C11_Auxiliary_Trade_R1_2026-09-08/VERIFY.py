#!/usr/bin/env python3
"""Read-only, standard-library mathematical replay of the C11 candidate.

This verifier does not import the search engine, NumPy, SciPy, or a solver.
It establishes finite data/admissibility/cardinality obligations. The short
Cartesian-product lifting proof is supplied in PROOF.md. It is not a Lean build.
"""
from __future__ import annotations
import argparse,copy,hashlib,itertools,json,math,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EXPECTED_SCHEMA="C11_AUXILIARY_TRADE_CERTIFICATE_V1"
class CheckFailed(Exception): pass

def require(ok: bool, message: str) -> None:
    if not ok: raise CheckFailed(message)

def decode(u: int) -> tuple[int,int,int]:
    return u%11,(u//11)%11,u//121

def conflict(u: int,v: int) -> bool:
    return all((a-b)%11 in (0,1,10) for a,b in zip(decode(u),decode(v)))

def independent(words: list[int],label: str) -> int:
    require(all(isinstance(w,int) and 0<=w<1331 for w in words),label+': invalid word')
    require(len(words)==len(set(words)),label+': repeated word')
    pairs=0
    for u,v in itertools.combinations(words,2):
        require(not conflict(u,v),label+': confusable pair '+str((u,v)))
        pairs+=1
    return pairs

def declared_tags(cert: dict, field: str, alphabet: str, arity: int) -> set[tuple[str,str]]:
    """Read descriptive tags without silently discarding malformed or duplicate entries.

    List order has no mathematical significance. Equality with the actual table
    difference is checked by run(), separately from its fixed-trade checks.
    """
    entries=cert.get(field)
    require(type(entries) is list,field+': metadata must be a list')
    tags=set()
    for entry in entries:
        require(type(entry) is list and len(entry)==2,field+': expected [family, word]')
        family,word=entry
        require(type(family) is str and len(family)==1 and family in alphabet,
                field+': invalid metadata family')
        require(type(word) is str and len(word)==arity and set(word)<=set(alphabet),
                field+': invalid metadata word')
        tag=(family,word)
        require(tag not in tags,field+': duplicate metadata tag')
        tags.add(tag)
    return tags

def run(data: dict, cert: dict) -> dict:
    require(type(cert) is dict,'certificate must be a mapping')
    require(cert.get('schema')==EXPECTED_SCHEMA,'unsupported certificate schema')
    require(data['source_commit']==cert['source_commit']=='aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65','commit mismatch')
    require(data['alphabet']=='BNADOHV','alphabet mismatch')
    abc=data['alphabet'];sep={tuple(s) for s in data['sep']}
    require(sep==set(map(tuple,'BO BH BV NA ND NO NH NV AD AH DV'.split())),'separation table mismatch')
    sep|={(b,a)for a,b in list(sep)}
    require(not any(a==b for a,b in sep),'reflexive separation')
    I=data['I'];X=data['X'];private=data['pairs'];P=[p for p,q in private];Q=[q for p,q in private]
    i_pairs=independent(I,'I');x_pairs=independent(X,'X')
    require(len(I)==len(X)==148,'base seed sizes')
    for p,q in private:
        require(p in I and q not in I,'private pair membership')
        require([v for v in I if conflict(q,v)]==[p],'private pair conflict set')
    footprint0={x for x in X if any(conflict(x,p)for p in P)}
    footprint1={x for x in X if any(conflict(x,q)for q in Q)}
    require(not footprint0&footprint1,'overlapping footprints')
    f={'B':sorted(set(I)-set(P)),'N':sorted(set(X)-footprint0-footprint1),'A':sorted(footprint0),'D':sorted(footprint1),'O':P,'H':Q,'V':P}
    for a,words in f.items(): independent(words,'family '+a)
    base_cross=0
    for a,b in sorted(sep):
        for u in f[a]:
            for v in f[b]:
                require(not conflict(u,v),'base separation '+a+b);base_cross+=1
    w={a:len(f[a])for a in abc}
    require([w[a]for a in abc]==[145,142,3,3,3,3,3],'base weights')
    layers={}
    for label,U in [('I',I),('X',X)]:
        layers[label]=[]
        for j in range(3):
            counts=[sum(decode(u)[j]==k for u in U)for k in range(11)]
            slack=[27-counts[k]-counts[(k+1)%11]for k in range(11)]
            require(sorted(slack)==[0]*10+[1],label+': layer rigidity')
            layers[label].append(counts)
    def separated(s,t): return any((a,b)in sep for a,b in zip(s,t))
    def check_table(tab,label):
        if isinstance(tab,list):
            require(len(tab)==len(set(tab)),label+': duplicate terminal word')
            for s,t in itertools.combinations(tab,2):require(separated(s,t),label+': terminal conflict')
            return {'within':math.comb(len(tab),2),'cross':0}
        require(set(tab)==set(abc),label+': output alphabet')
        lengths={len(s)for ss in tab.values()for s in ss};require(len(lengths)==1,label+': arity')
        within=cross=0
        for a in abc:
            require(len(tab[a])==len(set(tab[a])),label+': duplicate word')
            require(all(set(s)<=set(abc)for s in tab[a]),label+': input alphabet')
            for s,t in itertools.combinations(tab[a],2):
                require(separated(s,t),label+': within '+a+' '+s+' '+t);within+=1
        for a,b in sorted(sep):
            for s in tab[a]:
                for t in tab[b]:
                    require(separated(s,t),label+': cross '+a+b+' '+s+' '+t);cross+=1
        return {'within':within,'cross':cross}
    stats={name:check_table(tab,name)for name,tab in data['tables'].items()}
    new=cert['replacement_table'];stats['candidate']=check_table(new,'candidate')
    require(cert['replacement_node']=='x27','replacement node')
    old=data['tables']['T3c']
    old_tags={(a,s)for a in abc for s in old[a]};new_tags={(a,s)for a in abc for s in new[a]}
    require(old_tags-new_tags=={('N','ADA'),('N','HHA'),('A','NDA')},'removed tagged words')
    require(new_tags-old_tags=={('N','VHA'),('A','BDA')},'added tagged words')
    require(declared_tags(cert,'removed',abc,3)==old_tags-new_tags,'removed metadata/table mismatch')
    require(declared_tags(cert,'added',abc,3)==new_tags-old_tags,'added metadata/table mismatch')
    # Reconstruct the two conflict lists against the old table, not just a hash.
    blockers={}
    for a,s in new_tags-old_tags:
        blockers[a+':'+s]=sorted((b,t)for b,t in old_tags if (a==b or (a,b)in sep)and not separated(s,t))
    require(blockers['N:VHA']==[('N','ADA'),('N','HHA')],'VHA blocker list')
    require(blockers['A:BDA']==[('A','NDA'),('N','ADA')],'BDA blocker list')
    def poly(tab,children):
        def total(words):
            return sum(math.prod(children[i][a]for i,a in enumerate(s))for s in words)
        return total(tab) if isinstance(tab,list) else {a:total(tab[a])for a in abc}
    def replay(use_candidate):
        values={};dimensions={}
        for node in data['nodes']:
            name=node['name'];kind=node['kind']
            require(name not in values,'duplicate DAG name')
            if kind=='base':values[name]=w.copy();dimensions[name]=3
            else:
                ch=node['children'];require(all(c in values for c in ch),'non-topological DAG')
                tab=new if use_candidate and name=='x27' else data['tables'][kind]
                allwords=tab if isinstance(tab,list)else [s for ss in tab.values()for s in ss]
                require(all(len(s)==len(ch)for s in allwords),'DAG arity')
                values[name]=poly(tab,[values[c]for c in ch]);dimensions[name]=sum(dimensions[c]for c in ch)
        return values,dimensions
    old_values,ds=replay(False);new_values,ds1=replay(True)
    n0=old_values['root'];n1=new_values['root'];d=ds1['root']
    require(n0==int(data['N0'])==int(cert['N0']),'baseline integer')
    require(n1==int(cert['N1']),'candidate integer')
    require(ds['root']==d==data['dimension']==cert['dimension']==207,'dimension')
    require(n1-n0==int(cert['delta'])>0,'strict integer improvement')
    require(n1**207>n0**d,'cross-power comparison')
    require(all(new_values['x27'][a]==old_values['x27'][a]for a in 'BDOHV'),'unchanged x27 families')
    require(all(new_values[n]==old_values[n]for n in old_values if n not in ['x27','root']),'unintended downstream changes')
    lo=int(cert['decimal_lower_numerator']);hi=int(cert['decimal_upper_numerator']);den=int(cert['decimal_denominator'])
    require((lo,hi,den)==(5295492477500681,5295492477500682,10**15),'decimal bracket')
    require(lo**d<=n1*den**d<hi**d,'exact decimal bracket inequality')
    L=old_values['h7'];Y=old_values['p11'];Z=old_values['h9'];U=old_values['x29'];W=old_values['b13']
    require(L['B']-L['N']-L['A']+L['V']-L['H']==0,'factorization identity')
    cN=sum(U[s[1]]*W[s[2]]for s in data['tables']['K3a']if s[0]=='N')
    cA=sum(U[s[1]]*W[s[2]]for s in data['tables']['K3a']if s[0]=='A')
    require(cN==cA>0,'terminal coefficients')
    factors=[Z['A'],L['V']-L['H'],Y['H']-Y['D'],cN]
    require(all(t>0 for t in factors),'positive gain factors')
    require(math.prod(factors)==n1-n0,'factorized gain')
    return dict(status='PASS_EXACT_C11_IMPROVEMENT',dimension=d,N0=str(n0),N1=str(n1),delta=str(n1-n0),seed_pair_checks={'I':i_pairs,'X':x_pairs},base_ordered_cross_checks=base_cross,table_checks=stats,layers=layers,positive_gain_factors=[str(t)for t in factors],decimal_interval='[5.295492477500681, 5.295492477500682)',lean_build='NOT_RUN',external_review='SUPPLIED_AUTOMATED_REVIEW_ACCEPTS_UNCHANGED_FINITE_CERTIFICATE',verifier_revision='R1_METADATA_HARDENING',metadata_validation='SCHEMA_AND_EXACT_TAG_DIFFERENCES_PASS',repair_external_review='NOT_PERFORMED',priority_clearance='INCOMPLETE')

def integrity():
    path=ROOT/'MANIFEST.sha256'
    if not path.exists():return 0
    checked=0
    for line in path.read_text().splitlines():
        digest,name=line.split('  ',1);p=ROOT/name
        require(p.is_file(),'missing manifest file '+name)
        require(hashlib.sha256(p.read_bytes()).hexdigest()==digest,'hash mismatch '+name);checked+=1
    return checked

def negative_tests(data,cert):
    mutations=[]
    for a,s in [('N','ADA'),('N','HHA'),('A','NDA')]:
        c=copy.deepcopy(cert);c['replacement_table'][a].append(s);mutations.append((data,c,'restore '+a+':'+s))
    c=copy.deepcopy(cert);c['N1']=str(int(c['N1'])-1);mutations.append((data,c,'wrong cardinality'))
    c=copy.deepcopy(cert);c['dimension']=206;mutations.append((data,c,'wrong dimension'))
    dd=copy.deepcopy(data);dd['I'][1]=6;mutations.append((dd,cert,'confusable seed pair'))
    # F3 regressions exercise run() directly, without relying on the manifest.
    c=copy.deepcopy(cert);c['schema']='NOT_A_REAL_SCHEMA';c['removed']=[];c['added']=[]
    mutations.append((data,c,'F3 combined reproduction'))
    c=copy.deepcopy(cert);c['schema']='NOT_A_REAL_SCHEMA';mutations.append((data,c,'wrong schema alone'))
    c=copy.deepcopy(cert);del c['schema'];mutations.append((data,c,'missing schema'))
    c=copy.deepcopy(cert);c['schema']=None;mutations.append((data,c,'null schema'))
    for field in ('removed','added'):
        c=copy.deepcopy(cert);c[field]=[];mutations.append((data,c,'empty '+field+' metadata'))
        c=copy.deepcopy(cert);del c[field];mutations.append((data,c,'missing '+field+' metadata'))
        c=copy.deepcopy(cert);c[field].append(copy.deepcopy(c[field][0]))
        mutations.append((data,c,'duplicate '+field+' metadata tag'))
    c=copy.deepcopy(cert);c['removed'][0]=['N','BBB'];mutations.append((data,c,'wrong removed word'))
    c=copy.deepcopy(cert);c['added'][0]=['B','VHA'];mutations.append((data,c,'wrong added family'))
    c=copy.deepcopy(cert);c['removed'].append(['N','BBB']);mutations.append((data,c,'extra removed tag'))
    c=copy.deepcopy(cert);c['added'].append(['A','AAA']);mutations.append((data,c,'extra added tag'))
    c=copy.deepcopy(cert);c['removed']={};mutations.append((data,c,'removed metadata not list'))
    c=copy.deepcopy(cert);c['added']=None;mutations.append((data,c,'added metadata not list'))
    c=copy.deepcopy(cert);c['removed'][0]=['N'];mutations.append((data,c,'malformed removed pair'))
    c=copy.deepcopy(cert);c['added'][0]='NVHA';mutations.append((data,c,'added pair not list'))
    c=copy.deepcopy(cert);c['removed'][0]=[False,'ADA'];mutations.append((data,c,'non-string removed family'))
    c=copy.deepcopy(cert);c['added'][0]=['N',123];mutations.append((data,c,'non-string added word'))
    c=copy.deepcopy(cert);c['added'][0]=['N','VHZ'];mutations.append((data,c,'invalid added input letter'))
    c=copy.deepcopy(cert);c['removed'][0]=['N','AD'];mutations.append((data,c,'wrong removed word arity'))
    c=copy.deepcopy(cert);c['removed'],c['added']=c['added'],c['removed']
    mutations.append((data,c,'swapped added and removed metadata'))
    c=copy.deepcopy(cert);c['removed'][0]=['Z','ADA'];mutations.append((data,c,'invalid removed output letter'))
    passed=[]
    for d,c,name in mutations:
        try:run(d,c)
        except CheckFailed:passed.append(name)
        else:raise CheckFailed('negative control unexpectedly passed: '+name)
    return passed

def positive_tests(data,cert):
    """Do not accidentally demand a particular presentation order for metadata."""
    reference=run(data,cert)
    c=copy.deepcopy(cert)
    for field in ('removed','added'):c[field].reverse()
    require(run(data,c)==reference,'order-independent metadata control failed')
    return ['reordered added/removed lists preserve exact result']

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--self-test',action='store_true');args=ap.parse_args()
    try:
        count=integrity();data=json.loads((ROOT/'FROZEN_INPUTS.json').read_text());cert=json.loads((ROOT/'CANDIDATE.json').read_text())
        result=run(data,cert);result['manifest_files_checked']=count
        if args.self_test:
            result['negative_controls_rejected']=negative_tests(data,cert)
            result['positive_controls_passed']=positive_tests(data,cert)
        print(json.dumps(result,indent=2,sort_keys=True))
    except (CheckFailed,KeyError,ValueError,OSError)as e:
        print('FAIL: '+str(e),file=sys.stderr);raise SystemExit(1)
if __name__=='__main__':main()
