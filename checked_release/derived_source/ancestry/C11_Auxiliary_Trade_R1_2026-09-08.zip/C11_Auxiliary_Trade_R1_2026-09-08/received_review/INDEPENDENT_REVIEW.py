#!/usr/bin/env python3
"""Independent replay of the reviewed C11 archive; standard library only.

No code from the uploaded archive is imported or executed. Seed neighborhoods
are enumerated by modular coordinate shifts, not by the supplied conflict test.
The schedule and baseline tables below were checked against the pinned public
Lean sources using browser reads. They are transcriptions, not downloaded source
files and not a proof-assistant build. The final lifting step is a mathematical
induction reviewed in REVIEW.md.

Usage: python3 -B INDEPENDENT_REVIEW.py ORIGINAL.zip [--expand-b2]
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from decimal import Decimal, localcontext
from hashlib import sha256
from itertools import combinations, product
import json
from math import prod
from pathlib import Path
import platform
import sys
from zipfile import ZipFile

COMMIT = 'aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65'
DIGEST = 'b62863f7cd1718024a94a52683dd2fd2e95725bc9531832d8b37585450fb5b66'
PREFIX = 'C11_Auxiliary_Trade_2026-09-08/'
ABC = 'BNADOHV'
EDGES = {frozenset(s) for s in 'BO BH BV NA ND NO NH NV AD AH DV'.split()}
# Transcribed from BaseC11Data.lean, Ilist and Xlist, at COMMIT.
SOURCE_I = list(map(int, '''5 7 11 26 28 43 47 49 64 69 86 90 107 111
130 134 151 155 172 177 192 194 198 213 215 230 234 242
257 259 274 278 280 295 300 317 321 338 342 357 359 365
382 386 403 407 423 425 429 444 446 461 465 482 488 490
505 509 511 526 530 548 552 569 573 588 590 594 613 617
634 638 653 655 660 675 677 692 696 713 717 732 740 747
753 761 768 783 789 804 811 819 825 832 840 855 859 876
880 895 897 912 917 919 934 938 955 959 978 982 984 999
1003 1020 1024 1042 1046 1061 1063 1067 1082 1084 1090 1107 1111 1126
1128 1143 1147 1149 1165 1169 1186 1190 1207 1213 1230 1234 1251 1255
1272 1277 1292 1294 1298 1313 1315 1330'''.split()))
SOURCE_X = list(map(int, '''10 19 28 37 46 55 63 72 81 90 99 108 117 122
126 135 144 162 164 171 180 189 198 207 216 225 234 261
263 270 279 288 297 306 315 324 333 342 360 362 365 369
378 387 396 405 414 423 432 441 459 461 468 477 495 504
513 522 531 540 558 560 567 576 585 594 603 608 612 621
630 639 657 659 666 675 684 693 702 711 720 738 756 758
765 774 783 792 801 810 819 828 837 846 851 855 864 873
882 891 900 909 918 927 936 945 954 963 968 981 990 999
1008 1017 1026 1035 1044 1053 1062 1071 1080 1094 1098 1107 1116 1125
1134 1143 1152 1161 1170 1179 1188 1197 1206 1211 1224 1233 1242 1251
1260 1269 1278 1287 1296 1305 1314 1323'''.split()))

class Rejected(Exception):
    pass

def check(condition: bool, message: str) -> None:
    if not condition:
        raise Rejected(message)

def table(*rows: str) -> dict[str, list[str]]:
    check(len(rows) == len(ABC), 'incorrect table row count')
    return {a: row.split() for a, row in zip(ABC, rows, strict=True)}

T2A = table('BB HD VA DV AH', 'NN AA AD DA DD', 'AN ND', 'DN NA', 'ON NO', 'HN NV', 'VN NH')
T2B = table('AV BB DH', 'AA NN', 'AN BD DV VH', 'DN NA', '', 'HB NV', 'HA NH VD VN')
T3C = table(
    'ABV AHH AVA BBB DAH DHA DNH HAA HAN HHH NHD NVA VAD VDB',
    'AAD ADA BHD DAB DBH HHA HVH NNN VAA VDH',
    'ABN AND BNA BVV HDN NAB NDA VNV VVN',
    'DNN NDN NND', '', 'BHN HNB NBH',
    'AVN DHN HNA NAH NDV NNV NVN VND VNN')
T3D = table(
    'ABV BBB BHD BVA DAH DDV DNH HAA HAN VAD VDN VHA VHH',
    'AAD BHD DAB DBH HVH NNN VAA VDH VHA',
    'ABN AND BDA BNA BVV HDN NAB VNV VVN',
    'DNN NDN NND', '', 'BHN HNB NBH',
    'AVN DHN HNA NAH NDV NNV NVN VND VNN')
K3A = 'ABV AHN AVH BAB BDD BHA BNB DAH DDN DNH HBA HHH HVN NBV NHN NVH VBD VBN VVA'.split()
TABLES = {'T2a': T2A, 'T2b': T2B, 'T3c': T3C, 'K3a': K3A}

# Schedule is reconstructed separately, rather than trusted from FROZEN_INPUTS.
SCHEDULE: list[tuple[str, str, tuple[str, ...]]] = [('v', 'base', ()), ('g3', 'T3c', ('v', 'v', 'v'))]
SCHEDULE += [(f'h{k}', 'T2b', ('g3' if k == 4 else f'h{k-1}', 'v')) for k in range(4, 10)]
SCHEDULE += [(f'b{k}', 'T2b', ('v' if k == 2 else f'b{k-1}', 'v')) for k in range(2, 14)]
SCHEDULE += [('p11', 'T3c', ('g3', 'h6', 'b2')), ('x27', 'T3c', ('h7', 'p11', 'h9')),
             ('x29', 'T3c', ('h6', 'b12', 'p11')), ('root', 'K3a', ('x27', 'x29', 'b13'))]

def canonical(tab):
    if isinstance(tab, list):
        return sorted(tab)
    return {a: sorted(tab[a]) for a in sorted(tab)}

def separating_coordinates(s: str, t: str) -> list[int]:
    check(len(s) == len(t), 'unequal input word lengths')
    return [i for i in range(len(s)) if frozenset((s[i], t[i])) in EDGES]

def audit_table(tab, arity: int) -> dict[str, int]:
    terminal = isinstance(tab, list)
    if terminal:
        rows = {'terminal': tab}
    else:
        check(set(tab) == set(ABC), 'output alphabet mismatch')
        rows = tab
    tags = []
    for a, words in rows.items():
        check(len(words) == len(set(words)), f'duplicate in {a}')
        for s in words:
            check(len(s) == arity and set(s) <= set(ABC), f'malformed word {a}:{s}')
            tags.append((a, s))
    counts = {'within_unordered': 0, 'cross_unordered': 0}
    for (a, s), (b, t) in combinations(tags, 2):
        if a == b or frozenset((a, b)) in EDGES:
            check(bool(separating_coordinates(s, t)), f'conflict {a}:{s} / {b}:{t}')
            counts['within_unordered' if a == b else 'cross_unordered'] += 1
    return counts

def replay(base: dict[str, int], overrides=None):
    overrides = overrides or {}
    values, dims = {}, {}
    for name, kind, children in SCHEDULE:
        if kind == 'base':
            values[name], dims[name] = dict(base), 3
            continue
        tab = overrides.get(name, TABLES[kind])
        rows = {'root': tab} if isinstance(tab, list) else tab
        result = {}
        for a, words in rows.items():
            total = 0
            for s in words:
                check(len(s) == len(children), 'schedule arity mismatch')
                term = 1
                for index in range(len(children)):
                    term *= values[children[index]][s[index]]
                total += term
            result[a] = total
        values[name] = result['root'] if isinstance(tab, list) else result
        dims[name] = sum(dims[c] for c in children)
    return values, dims

def seed_neighborhoods():
    neighborhoods = {}
    for coords in product(range(11), repeat=3):
        u = sum(coords[i] * 11**i for i in range(3))
        neighbors = set()
        for shifts in product((-1, 0, 1), repeat=3):
            v = sum(((coords[i] + shifts[i]) % 11) * 11**i for i in range(3))
            neighbors.add(v)
        check(len(neighbors) == 27 and u in neighbors, 'closed neighborhood construction')
        neighborhoods[u] = neighbors
    check(len(neighborhoods) == 1331, 'cube universe')
    check(all(u in neighborhoods[v] for u, ns in neighborhoods.items() for v in ns), 'neighborhood asymmetry')
    return neighborhoods

def independent_set(words, neighbors, name):
    check(len(words) == len(set(words)), name + ': duplicate word')
    check(all(type(u) is int and 0 <= u < 1331 for u in words), name + ': invalid word')
    members = set(words)
    for u in members:
        check(neighbors[u] & members == {u}, name + ': nonindependent set')

def expand_b2(families, neighbors, expected):
    expanded = {}
    for a in ABC:
        pieces = [set(product(families[s[0]], families[s[1]])) for s in T2B[a]]
        expanded[a] = set().union(*pieces)
        check(len(expanded[a]) == sum(map(len, pieces)) == expected[a], 'b2 overlap/cardinality '+a)
    indexed = {}
    for a in ABC:
        indexed[a] = defaultdict(set)
        for u, v in expanded[a]:
            indexed[a][u].add(v)
    queries = 0
    for a in ABC:
        for b in ABC:
            if a != b and frozenset((a, b)) not in EDGES:
                continue
            for u, v in expanded[a]:
                for nu in neighbors[u]:
                    targets = indexed[b].get(nu)
                    if not targets:
                        continue
                    common = neighbors[v] & targets
                    if a == b and u == nu:
                        common.discard(v)
                    check(not common, f'physical b2 conflict {a}/{b}')
                    queries += 1
    return {'sizes': {a: len(expanded[a]) for a in ABC}, 'nonempty_first_block_queries': queries,
            'within_product_disjointness': 'PASS', 'physical_independence_and_required_cross_separation': 'PASS'}

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('archive', type=Path)
    ap.add_argument('--expand-b2', action='store_true')
    args = ap.parse_args()
    raw = args.archive.read_bytes()
    check(sha256(raw).hexdigest() == DIGEST, 'archive hash mismatch')
    with ZipFile(args.archive) as archive:
        check(len(archive.namelist()) == len(set(archive.namelist())), 'duplicate archive members')
        data = json.loads(archive.read(PREFIX + 'FROZEN_INPUTS.json'))
        cert = json.loads(archive.read(PREFIX + 'CANDIDATE.json'))
        manifest = archive.read(PREFIX + 'MANIFEST.sha256').decode().splitlines()
        names = set()
        for line in manifest:
            digest, name = line.split('  ', 1)
            check(name not in names, 'duplicate manifest member')
            names.add(name)
            check(sha256(archive.read(PREFIX + name)).hexdigest() == digest, 'manifest mismatch: '+name)
        all_files = {name[len(PREFIX):] for name in archive.namelist() if name.startswith(PREFIX) and not name.endswith('/')}
        check(names == all_files - {'MANIFEST.sha256'}, 'manifest completeness')
    check(data['source_commit'] == cert['source_commit'] == COMMIT, 'source commit')
    check(data['alphabet'] == ABC, 'alphabet')
    check({frozenset(s) for s in data['sep']} == EDGES, 'separation edges')
    check(data['I'] == SOURCE_I and data['X'] == SOURCE_X, 'browser-transcribed source seeds mismatch')
    check(data['pairs'] == [[5, 1215], [64, 65], [747, 736]], 'source private pairs')
    for name, tab in TABLES.items():
        check(canonical(tab) == canonical(data['tables'][name]), 'source table '+name)
    frozen_schedule = [(n['name'], n['kind'], tuple(n.get('children', []))) for n in data['nodes']]
    check(frozen_schedule == SCHEDULE, 'source schedule')
    source_check = 'PASS; browser-transcribed literal comparison, not a byte-identical source download'
    neighbors = seed_neighborhoods()
    for name in ('I', 'X'):
        check(len(data[name]) == 148, 'seed size')
        independent_set(data[name], neighbors, name)
    I, X = set(data['I']), set(data['X'])
    P, Q = {5, 64, 747}, {1215, 65, 736}
    for p, q in data['pairs']:
        check(p in I and q not in I and neighbors[q] & I == {p}, 'private pair')
    A = X & set().union(*(neighbors[p] for p in P))
    D = X & set().union(*(neighbors[q] for q in Q))
    check(not (A & D), 'footprint overlap')
    families = {'B': I-P, 'N': X-A-D, 'A': A, 'D': D, 'O': P, 'H': Q, 'V': P}
    for a in ABC:
        independent_set(list(families[a]), neighbors, a)
    base_cross_unordered = 0
    for pair in EDGES:
        a, b = tuple(pair)
        for u in families[a]:
            check(not (neighbors[u] & families[b]), 'base cross separation '+a+b)
            base_cross_unordered += len(families[b])
    base = {a: len(families[a]) for a in ABC}
    check(list(base.values()) == [145, 142, 3, 3, 3, 3, 3], 'base profile')
    mix = {a: list(T3D[a] if a in 'NA' else T3C[a]) for a in ABC}
    check(canonical(mix) == canonical(cert['replacement_table']), 'candidate does not equal source hybrid')
    check(cert['replacement_node'] == 'x27', 'replacement node')
    removed = {(a, s) for a in ABC for s in T3C[a]} - {(a, s) for a in ABC for s in mix[a]}
    added = {(a, s) for a in ABC for s in mix[a]} - {(a, s) for a in ABC for s in T3C[a]}
    check(removed == set(map(tuple, cert['removed'])), 'removed metadata')
    check(added == set(map(tuple, cert['added'])), 'added metadata')
    audits = {name: audit_table(tab, 2 if name.startswith('T2') else 3) for name, tab in TABLES.items()}
    audits['T3d'] = audit_table(T3D, 3)
    audits['candidate'] = audit_table(mix, 3)
    blockers = {}
    for a, s in sorted(added):
        blockers[a+':'+s] = sorted(b+':'+t for b in ABC for t in T3C[b]
                                  if (a == b or frozenset((a, b)) in EDGES) and not separating_coordinates(s, t))
    check(blockers == {'A:BDA': ['A:NDA', 'N:ADA'], 'N:VHA': ['N:ADA', 'N:HHA']}, 'blockers')
    check(separating_coordinates('VHA', 'BDA') == [0], 'new blocks mutual separation')
    old, dims = replay(base)
    new, dims1 = replay(base, {'x27': mix})
    n0, n1 = old['root'], new['root']
    check(n0 == int(data['N0']) == int(cert['N0']), 'baseline integer')
    check(n1 == int(cert['N1']), 'candidate integer')
    check(n1 - n0 == int(cert['delta']) > 0, 'exact gain')
    check(dims == dims1 and dims['root'] == data['dimension'] == cert['dimension'] == 207, 'physical dimension')
    check([n for n in old if old[n] != new[n]] == ['x27', 'root'], 'changed node scope')
    lo, hi, den = 5295492477500681, 5295492477500682, 10**15
    check((int(cert['decimal_lower_numerator']), int(cert['decimal_upper_numerator']), int(cert['decimal_denominator'])) == (lo, hi, den), 'bracket metadata')
    check(lo**207 < n1*den**207 < hi**207, 'exact bracket (strict at both ends)')
    x, y, z, u, v = [old[n] for n in ('h7', 'p11', 'h9', 'x29', 'b13')]
    dN = new['x27']['N'] - old['x27']['N']
    dA = new['x27']['A'] - old['x27']['A']
    check(dN == z['A']*((x['V']-x['H'])*y['H']-x['A']*y['D']), 'N change formula')
    check(dA == z['A']*y['D']*(x['B']-x['N']), 'A change formula')
    check(x['B']-x['N']-x['A']+x['V']-x['H'] == 0, 'h7 identity')
    suffixes = {a: sorted(s[1:] for s in K3A if s[0] == a) for a in 'NA'}
    check(suffixes['N'] == suffixes['A'] == ['BV', 'HN', 'VH'], 'terminal coefficient equality')
    C = u['B']*v['V']+u['H']*v['N']+u['V']*v['H']
    factors = [C, z['A'], x['V']-x['H'], y['H']-y['D']]
    check(all(f > 0 for f in factors) and prod(factors) == n1-n0, 'positive factorization')
    check(dN < 0 < dA and dN+dA == prod(factors[1:]), 'coordinated gain')
    with localcontext() as ctx:
        ctx.prec = 65
        r0 = (Decimal(n0).ln()/Decimal(207)).exp()
        r1 = (Decimal(n1).ln()/Decimal(207)).exp()
        approximations = {'baseline_root': str(r0), 'candidate_root': str(r1), 'root_gain': str(r1-r0),
                          'cardinality_percent_gain': str(100*Decimal(n1-n0)/Decimal(n0))}
    # A bounded adversarial comparator, not a global optimization claim.
    hybrid_comparisons = []
    for flags in product((False, True), repeat=3):
        choices = dict(zip('BNA', flags, strict=True))
        tab = {a: list(T3D[a] if choices.get(a, False) else T3C[a]) for a in ABC}
        entry = {'T3d_rows': ''.join(a for a in 'BNA' if choices[a]) or '(none)'}
        try:
            audit_table(tab, 3)
            alt, _ = replay(base, {'x27': tab})
            entry.update(admissible=True, root=str(alt['root']), delta_vs_baseline=str(alt['root']-n0), delta_vs_candidate=str(alt['root']-n1))
        except Rejected as error:
            entry.update(admissible=False, witness=str(error))
        hybrid_comparisons.append(entry)
    result = {'status': 'PASS_INDEPENDENT_FINITE_REPLAY', 'archive_sha256': DIGEST,
              'source_commit': COMMIT, 'source_literal_crosscheck': source_check,
              'environment': {'python': platform.python_version(), 'platform': platform.platform()},
              'manifest_files_checked': len(manifest), 'manifest_complete': True,
              'base_profile': base, 'base_families': {a: sorted(families[a]) for a in 'AD'},
              'base_cross_unordered': base_cross_unordered, 'table_checks': audits,
              'blockers': blockers, 'new_word_separation_coordinates_zero_based': [0],
              'dimensions': dims, 'N0': str(n0), 'N1': str(n1), 'delta': str(n1-n0),
              'delta_x27_N': str(dN), 'delta_x27_A': str(dA), 'delta_x27_N_plus_A': str(dN+dA),
              'positive_gain_factors_C_zA_VminusH_HminusD': [str(f) for f in factors],
              'exact_root_bracket': '(5.295492477500681, 5.295492477500682)',
              'approximations_not_used_in_acceptance': approximations,
              'x27_T3c_T3d_row_hybrids': hybrid_comparisons,
              'old_node_weights': old, 'candidate_x27_weights': new['x27'],
              'formal_build': 'NOT_RUN; no Lean/lake/elan executable present',
              'priority_clearance': 'INCOMPLETE'}
    if args.expand_b2:
        result['physical_b2_audit'] = expand_b2(families, neighbors, old['b2'])
    print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == '__main__':
    try:
        main()
    except (Rejected, OSError, ValueError, KeyError, TypeError) as error:
        print('REJECTED: '+str(error), file=sys.stderr)
        sys.exit(1)
