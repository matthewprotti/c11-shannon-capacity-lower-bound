#!/usr/bin/env python3
"""Exercise the supplied VERIFY.run on copies, without changing its input files.
Usage: python3 -B ADDITIONAL_MUTATIONS.py EXTRACTED_CHECKPOINT_DIRECTORY
This script deliberately imports the supplied verifier under test. It is not
part of INDEPENDENT_REVIEW.py and is not an independent mathematical proof.
"""
import argparse
import copy
import importlib.util
import json
from pathlib import Path

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('checkpoint', type=Path)
    args = ap.parse_args()
    spec = importlib.util.spec_from_file_location('subject_verifier', args.checkpoint/'VERIFY.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('Could not load subject verifier')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    data = json.loads((args.checkpoint/'FROZEN_INPUTS.json').read_text())
    cert = json.loads((args.checkpoint/'CANDIDATE.json').read_text())
    trials = []
    for a, word in [('N', 'ADA'), ('N', 'HHA'), ('A', 'NDA')]:
        c = copy.deepcopy(cert); c['replacement_table'][a].append(word)
        trials.append(('restore '+a+':'+word, data, c))
    c = copy.deepcopy(cert); c['replacement_table']['N'].append(c['replacement_table']['N'][0])
    trials.append(('duplicate candidate word', data, c))
    d = copy.deepcopy(data); d['tables']['K3a'].append(d['tables']['K3a'][0])
    trials.append(('duplicate terminal word', d, cert))
    d = copy.deepcopy(data); d['sep'].append('BN')
    trials.append(('invent separation BN', d, cert))
    d = copy.deepcopy(data); d['nodes'][-3]['children'] = ['h9', 'p11', 'h7']
    trials.append(('reverse x27 outside inputs', d, cert))
    d = copy.deepcopy(data); d['X'][1] = 5
    trials.append(('auxiliary seed includes parent', d, cert))
    c = copy.deepcopy(cert); c['decimal_lower_numerator'] = str(int(c['decimal_lower_numerator'])+1)
    trials.append(('raise claimed decimal lower endpoint', data, c))
    c = copy.deepcopy(cert); c['removed'] = []; c['added'] = []; c['schema'] = 'NOT_A_REAL_SCHEMA'
    trials.append(('inconsistent descriptive trade metadata and schema', data, c))
    results = []
    for name, d, c in trials:
        try:
            result = verifier.run(d, c)
            results.append({'test': name, 'outcome': 'ACCEPTED', 'status': result['status']})
        except Exception as error:
            results.append({'test': name, 'outcome': 'REJECTED', 'exception': type(error).__name__, 'message': str(error)})
    print(json.dumps({'scope': 'Calls VERIFY.run on in-memory copies; intentionally bypasses manifest checks to test mathematical and metadata validation. The original archive was not changed.', 'tests': results}, indent=2))

if __name__ == '__main__':
    main()
