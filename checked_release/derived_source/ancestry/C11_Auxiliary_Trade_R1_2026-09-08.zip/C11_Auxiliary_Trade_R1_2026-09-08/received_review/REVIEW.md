# Adversarial review: C11 auxiliary-trade checkpoint

Review date: 8 September 2026.

## Verdict

**CORRECT_FINITE_CERTIFICATE_WITH_REMAINING_FORMAL_OR_PRIORITY_GATES**

The narrow construction claim survives this review. Independently reconstructed base families, finite substitution conditions, physical dimension, full cardinalities, and exact rational inequalities agree with the checkpoint. The Cartesian-product lifting argument is valid. No counterexample to the claimed improvement was found.

This is an automated adversarial review with a separately written implementation, not a human referee report, a completed Lean build, global optimality certification, or worldwide priority clearance. The original checkpoint has not been altered or replaced by a stronger candidate.

## 1. Object and execution environment

Archive: `C11_Auxiliary_Trade_Checkpoint_2026-09-08.zip`.

SHA-256:

```text
b62863f7cd1718024a94a52683dd2fd2e95725bc9531832d8b37585450fb5b66
```

Pinned upstream commit:

```text
aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65
```

Execution environment: CPython 3.13.5, Linux 6.18.35, x86_64. No `lean`, `lake`, or `elan` executable was found on PATH. The upstream `lean-toolchain` specifies Lean 4.32.2 [S7].

The archive hash equals the hash supplied with the request. All 26 entries of its internal manifest match. The independently written audit also checked that the manifest covers every archived file except the manifest itself and that archive member names are not duplicated.

Both `python3 -B VERIFY.py --self-test` and `python3 -O -B VERIFY.py --self-test` return `PASS_EXACT_C11_IMPROVEMENT`. Their output files are identical. Each rejects all six supplied negative controls. The fresh report records 26 manifest files checked, rather than the archived report's zero; the package already documents that difference.

The independent program, `INDEPENDENT_REVIEW.py`, also passes normally and under `-O`, with identical reports. It never imports or executes checkpoint code. It enumerates each cube vertex's closed neighborhood by all 27 modular coordinate shifts, uses a separately written tagged-pair admissibility check, and reconstructs the schedule independently. Floating-point arithmetic is not used to accept the certificate. Decimal logarithms are used only to display approximations after exact acceptance.

## 2. Upstream comparison and its boundary

The pinned public `BaseC11Data.lean`, `PortRealisation.lean`, `Substitutions.lean`, `TerminalCodes.lean`, and `CertC11.lean` were read through the browser. The seed literals, private pairs, separation system, original tables, schedule, and baseline integer agree with the checkpoint [S1-S5]. Browser-transcribed literals are included in the independent checker and compared against the archive.

This was not a byte-for-byte source download. Direct container downloads failed with `Temporary failure in name resolution`; the GitHub API request also failed. No upstream source-file hash comparison or repository build is claimed. Reading the pinned code and independently reproducing its mathematical objects nonetheless removes reliance on the checkpoint's unaudited transcription alone.

The important source convention is the executable base-11 encoding, not a coordinate-order comment: `u = x0 + 11*x1 + 121*x2`. The independent neighborhood construction uses exactly that convention [S1].

## 3. Base realization and finite checks

Both literal seeds contain 148 distinct vertices of the strong cube, and each is independent. This covers 10,878 unordered pairs per seed. All three selected private pairs have exactly their stated single blocker in I. The footprints are

```text
A = {63, 126, 758}
D = {55, 846, 1094}
```

They are disjoint. The seven base sizes, in order `(B,N,A,D,O,H,V)`, are

```text
(145,142,3,3,3,3,3).
```

All seven families are independently checked, and all eleven required cross-family separations hold. There are 3,462 unordered cross-family comparisons, or 6,924 when both orientations are counted. Equality is included in the conflict relation. In particular, the proof does not confuse “not adjacent” with “distinct and nonconfusable.” The separation system matches the public `Letter.sep` definition [S2].

Finite table counts from the independent audit are:

| Object | Within-family unordered pairs | Cross-family unordered pairs |
|---|---:|---:|
| T2a, unused by the final schedule | 25 | 92 |
| T2b | 18 | 66 |
| T3c | 214 | 489 |
| T3d, extra comparator | 192 | 453 |
| Candidate T* | 205 | 465 |
| Terminal K3a | 171 | 0 |

Every required pair passes. The checkpoint counts cross-family orientations separately, so its 930 candidate cross checks equal the independent audit's 465 unordered checks; this is not a discrepancy.

As an additional test beyond symbolic arithmetic, I materialized the seven b2 families as actual pairs of cube vertices. Their sizes are

```text
(B,N,A,D,O,H,V) = (21043,20173,879,852,0,861,870).
```

For these explicit six-dimensional sets, I checked that products within each output family are disjoint, their union cardinalities equal the polynomial counts, each family is independent, and every required cross-family pair is separated. This is not an enumeration of the final 150-digit-sized set; it is an extra direct check of the first binary substitution.

## 4. Lifting argument: why the integer is a cardinality

This is the main conceptual attack surface. The seven realized sets are not assumed pairwise disjoint globally; indeed O and V coincide at the base. Consequently, simply adding sizes of arbitrary products would be invalid.

For one symbolic word, its Cartesian product is independent: any two distinct resulting vectors differ in a block, and that block's independent set supplies a nonconfusable coordinate. For two different symbolic words in the same output row, table admissibility supplies a block whose letter sets are mutually nonconfusable. The resulting products are therefore mutually nonconfusable and disjoint. A common element would conflict with itself in that block, contradicting separation. Thus the union's size really is the sum of product sizes, with no inclusion-exclusion correction.

The same argument preserves required separation between output families. Applying it inductively through the acyclic schedule and finally to K3a establishes the independent set with the computed size. Reusing a DAG node means taking copies of its set in separate coordinate blocks, not constraining the copies to contain the same selected word. Therefore shared subexpressions do not reduce the physical dimension or invalidate the product count.

This is precisely the kind of construction already supported by BPZ's `Realisation.multiSubst`, `card_multiSubstSet`, and terminal-code machinery [S6]. It is not a new general composition theorem.

## 5. The trade survives the local attacks

At x27, the table change is exactly

```text
Remove: N:ADA, N:HHA, A:NDA
Insert: N:VHA, A:BDA
```

Checking against the entire old table, rather than a hand-picked subset, gives

```text
blockers(N:VHA) = {N:ADA, N:HHA}
blockers(A:BDA) = {N:ADA, A:NDA}
```

There are no other blockers. The two inserted blocks separate in their first coordinate, because V and B are a designated separation pair. All three removals are needed for these insertions in the stated local trade.

The N and A rows are exactly T3d's corresponding rows, while all remaining rows are T3c's [S3]. There are only three differing rows between these two published tables: B, N, and A. I therefore additionally checked all eight distinct rowwise T3c/T3d hybrids at x27, holding everything else fixed. Six are admissible. The submitted N+A hybrid is the only one strictly better than the baseline and is the best of this eight-member comparison class. A-only is inadmissible because of N:ADA against A:BDA; N-only loses cardinality; the entire T3d table also loses cardinality. This supports the coordinated nature of the improvement, but is not an optimality claim over other tables, schedules, or seed choices.

## 6. Exact dimension, cardinalities, and gain

The terminal children have dimensions 81, 87, and 39. Equivalently,

```text
3*(27+29+13) = 207.
```

The independently reconstructed baseline equals upstream M [S5]:

```text
N0 = 705688158939417766083006128695703821080101605304173623991920300506716846627203440324635068341693109509608786929844839653207121849017872676157797788816
```

With x27 alone changed:

```text
N1 = 705692619930489413584189552943991443716392885026759451863953624242911159057444856108323516589876967077721069272782760798453832061060020786354479288616
```

The exact gain is

```text
N1 - N0 = 4460991071647501183424248287622636291279722585827872033323736194312430241415783688448248183857568112282342937921145246710212042148110196681499800
```

Only x27 and root change. The changes to x27's N and A components are

```text
Delta N = -122098945967685542472292004026883924985455229061655054700
Delta A = 122929564382764800305634466081533542881219368309634819800
```

In particular, N decreases. A componentwise-monotonicity argument would be wrong. The correct proof uses compensation between the two components.

Writing x,y,z for h7,p11,h9, the directly computed changes agree with

```text
Delta N = z_A*((x_V-x_H)*y_H - x_A*y_D)
Delta A = z_A*y_D*(x_B-x_N)
x_B-x_N-x_A+x_V-x_H = 0
Delta(N+A) = z_A*(x_V-x_H)*(y_H-y_D).
```

The terminal's N- and A-prefix words have the same suffix set `{BV,HN,VH}` [S4]. Their common coefficient is `C = u_B*v_V + u_H*v_N + u_V*v_H`, for u=x29 and v=b13. Consequently,

```text
N1-N0 = C*z_A*(x_V-x_H)*(y_H-y_D)
```

with positive factors

```text
C       = 5370686455611307644065162021468274289522717206329834451070722702496985203436218065169865298
z_A     = 5693880288864205575
x_V-x_H = 11688171445791
y_H-y_D = 12480921449919238353228
```

Their product agrees exactly with the full recursion gain. The intermediate increase is

```text
Delta(N+A) = 830618415079257833342462054649617895764139247979765100
```

The independently verified rational inequalities are slightly stronger than the stated closed lower endpoint:

```text
5295492477500681^207 < N1*(10^15)^207 < 5295492477500682^207.
```

Thus the root lies strictly between 5.295492477500681 and 5.295492477500682, and the construction proves the advertised lower bound on capacity. The bracket's upper endpoint bounds the root of this particular construction, not Shannon capacity itself.

Descriptive approximations, not acceptance criteria:

```text
N0^(1/207) = 5.2954923157846201425507789858617...
N1^(1/207) = 5.2954924775006811290550921547844...
Root increase = 1.617160609865043...e-7
Cardinality increase = 0.000632147644131077... percent
```

## 7. Findings and remaining gates

### F1 — End-to-end Lean verification is absent: a promotion gate

`CandidateTrade.lean` defines a proposed admissible table and proves inequalities about literal natural numbers, subject to the file building. It does not connect N1 to the size of a realized independent set and does not prove the new capacity theorem. Even a successful build of this fragment alone would not close that gap.

The remaining work is to instantiate the hybrid at Rx27, establish its new seven weights, replace the first terminal child while retaining x29 and b13, prove the new independent-set bound, and pass through the existing cycle/strong-power/capacity interface. Build the complete theorem in the pinned environment and inspect its axioms. No build was performed in this review. The checkpoint already acknowledges this boundary accurately.

### F2 — Priority and a worldwide-record claim remain unestablished

On the repository pages retrieved during this review, BPZ main's latest listed commit is the pinned 10 August 2026 update [S8], and its current Main.lean states 5.295492315784620 for C11 [S9]. The arXiv record retrieved for BPZ still lists only v1, dated 31 July 2026, with the older 5.294502522149... bound [S10]. These are distinct versions, not conflicting baselines.

The visible fork, the Itty et al. paper and author repository, Tandon's paper, and targeted searches were also checked at a bounded level [S11-S13]. No stronger C11 certificate or already published exact hybrid was identified in the material inspected. This is not a comprehensive search of all repositories, branches, unpublished work, or mathematically equivalent constructions. Tandon's Remark 3 discusses a broader two-sided extension; the checkpoint does not establish it [S13].

The defensible contribution is a useful local row hybrid and exact improvement within an existing framework. Numerical validity does not establish priority, theoretical breadth, or a guaranteed significance rating.

### F3 — Minor metadata-validation weakness

In an in-memory test of `VERIFY.run`, setting `removed=[]`, `added=[]`, and `schema="NOT_A_REAL_SCHEMA"` still returns PASS. The mathematical table difference is checked independently of these descriptive fields, so this does not invalidate the sealed certificate. A changed on-disk CANDIDATE would also fail the original manifest check. This is a schema/metadata hardening issue, not a demonstrated false mathematical acceptance.

Recommended repair: validate the expected schema and require the listed added/removed fields to equal the actual tagged-set differences. Keep the external archive digest as the authenticity/integrity anchor. The independent reviewer script already checks the added/removed metadata for this archive.

### F4 — Search failures must not be promoted to obstruction theorems

The orbit, MILP, and local-exchange searches were not all rerun. The interrupted solver call has no completed result. None of those negative claims is needed for the positive certificate, and the checkpoint's ledger correctly limits their scope. The eight-hybrid comparison in this review likewise says nothing about larger search spaces.

## 8. Reproduction

From the extracted original checkpoint directory:

```sh
python3 -B VERIFY.py --self-test
python3 -O -B VERIFY.py --self-test
sha256sum -c MANIFEST.sha256
```

The independent reviewer program takes the original ZIP directly:

```sh
python3 -B INDEPENDENT_REVIEW.py /path/to/C11_Auxiliary_Trade_Checkpoint_2026-09-08.zip --expand-b2
python3 -O -B INDEPENDENT_REVIEW.py /path/to/C11_Auxiliary_Trade_Checkpoint_2026-09-08.zip --expand-b2
```

For the extra mutation tests of the supplied verifier:

```sh
python3 -B ADDITIONAL_MUTATIONS.py /path/to/extracted/C11_Auxiliary_Trade_2026-09-08
```

The included JSON reports retain full weights, dimensions, exact alternative-hybrid results, and mutation error messages. All three restored blocker tests fail for specific within-family conflicts. Additional duplicate-word, invented-separation, wrong-order, seed-conflict, and raised-decimal tests also fail as intended.

**Bottom line:** accept the exact finite construction improvement; do not label it a completed Lean-verified new capacity bound or a globally priority-cleared record.

## Public sources inspected

These are reference URLs, not bundled raw source files. Pinned Lean source paths in S1-S7 are under the exact commit above. Date of browser inspection: 8 September 2026.

[S1] Base seed data and encoding

```text
https://raw.githubusercontent.com/spectra-research/shannon-capacity-lean/aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65/ShannonBounds/BaseC11Data.lean
```

[S2] Seven-family separation system

```text
https://raw.githubusercontent.com/spectra-research/shannon-capacity-lean/aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65/ShannonBounds/PortRealisation.lean
```

[S3] Substitution library, including T3c/T3d

```text
https://raw.githubusercontent.com/spectra-research/shannon-capacity-lean/aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65/ShannonBounds/Substitutions.lean
```

[S4] Terminal code K3a

```text
https://raw.githubusercontent.com/spectra-research/shannon-capacity-lean/aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65/ShannonBounds/TerminalCodes.lean
```

[S5] Pinned exact C11 certificate and schedule

```text
https://raw.githubusercontent.com/spectra-research/shannon-capacity-lean/aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65/ShannonBounds/CertC11.lean
```

[S6] Multilinear lifting and cardinality proofs

```text
https://raw.githubusercontent.com/spectra-research/shannon-capacity-lean/aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65/ShannonBounds/Layered.lean
```

[S7] Pinned Lean toolchain

```text
https://raw.githubusercontent.com/spectra-research/shannon-capacity-lean/aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65/lean-toolchain
```

[S8] Upstream commit history

```text
https://github.com/spectra-research/shannon-capacity-lean/commits/main/
```

[S9] Current main theorem file

```text
https://raw.githubusercontent.com/spectra-research/shannon-capacity-lean/main/ShannonBounds/Main.lean
```

[S10] BPZ arXiv version record

```text
https://arxiv.org/abs/2607.29681
```

[S11] Visible fork

```text
https://github.com/xyz2606/shannon-capacity-lean
```

[S12a] Itty et al. arXiv record

```text
https://arxiv.org/abs/2607.21517
```

[S12b] Itty et al. author repository

```text
https://github.com/nathanielitty/lower-bounds-for-shannon-capacity
```

[S13] Tandon, including Remark 3

```text
https://arxiv.org/html/2608.30273v1
```
