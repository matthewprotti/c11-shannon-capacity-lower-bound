# C11 adversarial-review evidence

Read `REVIEW.md` for the verdict and scope. `INDEPENDENT_REVIEW.py` takes the original checkpoint ZIP as input and does not import checkpoint code. It checks the original archive hash and independently reconstructs the finite certificate. Add `--expand-b2` for the direct six-dimensional set check used in this review.

`INDEPENDENT_REPORT.json` and `INDEPENDENT_OPTIMIZED_REPORT.json` are identical normal/`-O` runs. The two `SUPPLIED_VERIFIER*` reports are identical normal/`-O` replays of the checkpoint's verifier. `ADDITIONAL_MUTATIONS.py` separately imports that verifier under test; its JSON report records errors and the accepted inconsistent descriptive metadata. All mutations are in-memory copies.

`SOURCE_AUDIT.json` records the public source references and access limitations. `VERDICT.json` is a machine-readable review outcome. `REVIEW_MANIFEST.sha256` hashes every evidence file except itself.

The original checkpoint is not included or modified. No Lean build or comprehensive priority clearance is claimed.
