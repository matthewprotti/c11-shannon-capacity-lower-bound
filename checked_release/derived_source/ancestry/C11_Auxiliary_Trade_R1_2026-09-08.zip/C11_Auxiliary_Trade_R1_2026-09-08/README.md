# C11 auxiliary trade — R1 review repair, 8 September 2026

**Controlling status:** `CORRECT_FINITE_CERTIFICATE_WITH_REMAINING_FORMAL_OR_PRIORITY_GATES`.

The supplied automated adversarial review accepts the exact finite construction and its Cartesian-product lifting argument. The unchanged construction proves

\[
\Theta(C_{11})\ge 5.295492477500681.
\]

The unchanged candidate root lies strictly between 5.295492477500681 and 5.295492477500682, by the supplied independent replay. The upper endpoint bounds this constructed root, **not Shannon capacity**.

R1 fixes the descriptive metadata-validation weakness F3. It does not change the construction, seed data, table, schedule, cardinalities, dimension, proof text, or unbuilt Lean fragment. Read `REPAIR_NOTE.md` for the repair and test scope; `RELEASE_STATUS.json` records the current disposition.

## Replay this release

From this extracted directory:

```sh
python3 -B VERIFY_PACKAGE.py
python3 -O -B VERIFY_PACKAGE.py
```

Expected status: `PASS_C11_R1_RELEASE`. The package wrapper requires a complete manifest, checks the parent/review archive digests, establishes byte identity of accepted mathematical files, runs the repaired verifier with its self-tests, reruns the unchanged independent reviewer against the original parent ZIP including the direct six-dimensional b2 check, and runs the unchanged reviewer's mutation suite against R1. Normal and optimized outputs are identical.

For only the repaired mathematical/metadata verifier:

```sh
python3 -B VERIFY.py --self-test
python3 -O -B VERIFY.py --self-test
```

Expected status: `PASS_EXACT_C11_IMPROVEMENT`. Thirty negative controls are rejected. A positive control accepts reordered descriptive tag lists. The underlying `VERIFY.py` retains the original behavior of checking a manifest when present; use `VERIFY_PACKAGE.py` for mandatory manifest and full release checks.

No third-party Python packages, solver, network access, or Lean installation is needed. Use Python 3.10 or newer; replay here used CPython 3.13.5. Explicit exceptions, not Python assertions, enforce acceptance. Replay is read-only; do not redirect new output into this sealed directory because manifest coverage would change.

`VERIFICATION_REPORT.json` and `RELEASE_VERIFICATION_REPORT.json` match fresh normal/optimized runs of the corresponding commands. `LINEAGE_LOCK.json` records the two ancestor hashes and unchanged mathematical file hashes. The external ZIP digest remains the release integrity anchor: an internally rewritten manifest is not authentication.

## Contents and provenance

- `PROOF.md`, `CANDIDATE.json`, `FROZEN_INPUTS.json`, and `CandidateTrade.lean` are byte-identical to the independently reviewed checkpoint.
- `VERIFY.py` is the patched verifier; `VERIFY_R1.patch` is the exact diff. `VERIFY_PACKAGE.py` is a new release-check wrapper, not an independent mathematical proof.
- `received_review/` preserves every received review evidence file byte-for-byte. `ancestry/` holds both original ZIP archives unchanged.
- `replay_reports/` records the original F3 reproduction, the received independent checker's normal/optimized reruns, and its mutation tests against R1.
- `LEAN_INTEGRATION_BRIEF.md` defines the next narrow formalization gate. `CandidateTrade.lean` remains an **unbuilt fragment**, not an end-to-end capacity theorem.

Some immutable original files still state that external review is pending or absent. Those are historical statements about the initial checkpoint, not the R1 release disposition. Similarly, stored reports inside `received_review/` describe the original verifier, including its pre-repair weakness. No historical evidence has been silently edited.

**Remaining boundaries:** no new independent review of the R1 patch; no end-to-end Lean build; no new literature scan or worldwide priority clearance; no global optimality claim; no significance rating. The exploration ledger is preserved and was not rerun. The review's eight-hybrid comparison concerns only that fixed finite class.
