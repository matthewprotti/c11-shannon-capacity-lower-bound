# A coordinated auxiliary trade in the BPZ C11 certificate

**Date:** 8 September 2026.  
**Claim:** an explicit independent set in the 207th strong power of C11 whose cardinality exceeds the exact BPZ certificate at commit `aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65`.  
**Verification status:** the finite obligations and exact arithmetic have been replayed by a separate standard-library verifier. No Lean build or external adversarial review has been completed for the modification. Priority clearance is incomplete.

## 1. Frozen input and claim boundary

The source is Pjotr Buys, Sven Polak, and Jeroen Zuiddam, *Lean-verified lower bounds for the Shannon capacity of odd cycles*, repository `spectra-research/shannon-capacity-lean`. We freeze the commit above, not an unversioned decimal displayed on a tracker.

The 150-digit baseline is

```text
705688158939417766083006128695703821080101605304173623991920300506716846627203440324635068341693109509608786929844839653207121849017872676157797788816
```

The candidate cardinality is

```text
705692619930489413584189552943991443716392885026759451863953624242911159057444856108323516589876967077721069272782760798453832061060020786354479288616
```

Call these integers N0 and N1. Both constructions have dimension 207. The exact integer checker establishes

\[
N_1>N_0,\qquad N_1^{207}>N_0^{207},
\]

and the rational bracket

\[
\left(\frac{5295492477500681}{10^{15}}\right)^{207}
\le N_1 <
\left(\frac{5295492477500682}{10^{15}}\right)^{207}.
\]

Consequently the constructed set gives

\[
\Theta(C_{11})\ge N_1^{1/207}\ge5.295492477500681.
\]

**The upper endpoint in this bracket bounds the root of our constructed cardinality, not Shannon capacity itself.**

The candidate root is approximately 5.2954924775006811290550921547844, whereas the frozen baseline root is approximately 5.2954923157846201425507789858617. These approximations are descriptive; the proof uses integer arithmetic.

This is a local improvement using BPZ's existing substitution framework. In particular it does **not** solve Tandon's general two-sided heterogeneous extension problem. Its N and A rows are the corresponding published T3d rows, while its other rows are T3c rows. The actual construction change is a useful hybrid at one specified node; the general Cartesian-product lifting mechanism belongs to the existing framework.

## 2. Construction model and lifting proof

For residues a,b modulo 11, call them confusable when their difference is 0, 1, or -1. Words are confusable when every coordinate is confusable. A set of distinct pairwise nonconfusable words is an independent set in the corresponding strong power of C11.

Use the alphabet B,N,A,D,O,H,V. Its unordered separation pairs are

```text
BO BH BV NA ND NO NH NV AD AH DV
```

A realization consists of one independent set for each letter, with all pairs of sets designated by this table mutually nonconfusable. Sets whose letters are not designated separated may overlap; the checker never treats absence of a separation edge as a separation certificate.

Given realizations in dimensions d1,...,dq, an input word a1...aq represents the Cartesian product of its q letter sets. That product is independent: two distinct points differ in at least one block, and the independent set in that block separates them.

Two such product sets are disjoint and mutually nonconfusable whenever some input coordinate carries a designated separation pair. Therefore a table of input words assigned to output letters is admissible precisely under the sufficient conditions checked here:

* Distinct input words assigned to one output letter have a designated separating coordinate.
* Input words assigned to separated output letters have a designated separating coordinate.

The corresponding unions then form another realization in dimension d1+...+dq, with sizes

\[
w'(a)=\sum_{s\in T(a)}\prod_{j=1}^{q}w_j(s_j).
\]

No inclusion-exclusion correction is required: within one output family, designated separation also proves disjointness. A terminal word set with the same pairwise property yields a single independent set. This argument is BPZ's existing `Realisation.multiSubst`/terminal-code mechanism, not a new claimed abstract composition theorem.

## 3. Base realization

`FROZEN_INPUTS.json` contains the exact 148-word I and X lists extracted from BPZ's `BaseC11Data.lean`. A word with identifier u has coordinates

\[
(u\bmod11,\ \lfloor u/11\rfloor\bmod11,\ \lfloor u/121\rfloor).
\]

The selected private pairs, as integer identifiers, are

```text
(5,1215), (64,65), (747,736).
```

Let P be the three parents and Q the three alternatives. The seven families are

\[
B=I\setminus P,\quad O=V=P,\quad H=Q,
\]

\[
A=\{x\in X:x\text{ conflicts with }P\},\qquad
D=\{x\in X:x\text{ conflicts with }Q\},
\]

\[
N=X\setminus(A\cup D).
\]

The two footprints A and D are disjoint. Direct checks prove independence and every specified separation, giving weights

\[
(B,N,A,D,O,H,V)=(145,142,3,3,3,3,3).
\]

The verifier checks all 10,878 unordered pairs in each of I and X, rechecks each family, checks private-neighbor conditions, and performs 6,924 ordered cross-family tests. Its correctness does not require trusting an external solver or accepting a source comment as an independence certificate.

The supplied layer-rigidity observation is also checked on both literal seeds. For any 148-word independent set in the cube, the adjacent-layer bounds give ten adjacent sums of 27 and one of 26. The odd-cycle recurrence determines the stated alternating 13/14 pattern up to rotation. This observation is a constraint on optimal seeds, not a claimed new capacity result.

## 4. Unchanged recursion

The names below count three-dimensional base blocks. Thus `h7` lives in dimension 21, not dimension 7.

```text
v = base
G = T3c
H = T2b

g3 = G(v,v,v)
h4 = H(g3,v)
h(j+1) = H(hj,v), j=4,...,8

b2 = H(v,v)
b(j+1) = H(bj,v), j=2,...,12

p11 = G(g3,h6,b2)
x27 = G(h7,p11,h9)
x29 = G(h6,b12,p11)
root = K3a(x27,x29,b13)
```

The terminal dimension is 3*(27+29+13)=207. The original tables and full directed acyclic graph are included in the frozen data. Their exact replay gives N0.

## 5. The local trade

At **x27 only**, replace the T3c substitution by T*. Concatenated letters denote products using the ordered inputs `(h7,p11,h9)`.

| Output family | Remove these input words | Add these input words |
|---|---|---|
| N | ADA, HHA | VHA |
| A | NDA | BDA |

All B,D,O,H,V rows are unchanged. All other recursion nodes and the terminal code are unchanged. The original substitution has 48 tagged words; this one has 47. Fewer symbolic blocks can produce more actual codewords because the blocks have different sizes.

### Why the modified table is admissible

Against the entire original T3c table, the new N:VHA block has exactly these blockers:

```text
N:ADA, N:HHA
```

The new A:BDA block has exactly these blockers:

```text
N:ADA, A:NDA
```

All three blockers are removed by the trade. The new blocks themselves must be separated because N and A are a separated output pair. They are: their first-coordinate letters V and B are separated.

The full checker independently tests 205 unordered within-family word pairs and 930 ordered cross-family word pairs for T*. Both tests pass. This establishes admissibility independently of any numerical weight advantage.

## 6. Exact gain and its factorization

Write x,y,z for the weight vectors at h7,p11,h9. Only the output N and A sizes change:

\[
\Delta N=z_A[(x_V-x_H)y_H-x_Ay_D],
\]

\[
\Delta A=z_Ay_D(x_B-x_N).
\]

The frozen h7 profile satisfies

\[
x_B-x_N-x_A+x_V-x_H=0.
\]

Thus

\[
\Delta(N+A)=z_A(x_V-x_H)(y_H-y_D).
\]

Every factor is positive, with exact values

```text
z_A           = 5693880288864205575
x_V - x_H     = 11688171445791
y_H - y_D     = 12480921449919238353228
```

Their product is

```text
830618415079257833342462054649617895764139247979765100
```

The old and new N values alone do not monotonically improve: N decreases and A increases by more. The gain is coordinated, not a componentwise enlargement.

Now let u and v be the weights at x29 and b13. In terminal K3a the coefficient of the first input's N is exactly the coefficient of its A, since the words beginning with N and A have identical two-letter suffix lists `{BV,HN,VH}`. The common coefficient is

\[
C=u_Bv_V+u_Hv_N+u_Vv_H>0,
\]

namely

```text
5370686455611307644065162021468274289522717206329834451070722702496985203436218065169865298
```

Therefore

\[
N_1-N_0=C\,z_A(x_V-x_H)(y_H-y_D)>0.
\]

The exact difference is

```text
4460991071647501183424248287622636291279722585827872033323736194312430241415783688448248183857568112282342937921145246710212042148110196681499800
```

A separate full recursion replay agrees with this factorized difference. The resulting code has about 0.0006321476 percent more words at the same dimension. The increase in the root is approximately 1.61716061e-7. Neither approximation is used to decide the improvement.

## 7. Trust and novelty boundaries

The positive certificate consists of explicit base words, explicit finite tables, a directed acyclic construction, and exact integers. The standard-library verifier reads those objects and proves the finite obligations; the lifting argument above supplies their consequence for a graph power. It does not enumerate the final enormous independent set.

The search and verifier are separately implemented but share the frozen input data. This is not an external independent review. Literal inputs were transcribed from authenticated connector reads, not obtained by a successful local git clone. The baseline match is checked mathematically; the package does not claim a byte-for-byte upstream source archive.

`CandidateTrade.lean` is an **unbuilt** formalization fragment for table admissibility and integer inequalities. It does not contain a completed replacement of the full BPZ capacity proof, and must not be called a Lean-verified new bound.

A current README reread on 8 September continued to list the frozen C11 baseline. A few targeted searches did not establish complete priority clearance. This package makes no unconditional worldwide record claim, no peer-review claim, no VibeMathed significance-score claim, and no solution of Tandon's general two-sided extension.

## Sources

1. BPZ repository, frozen commit: https://github.com/spectra-research/shannon-capacity-lean/tree/aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65
2. `ShannonBounds/BaseC11Data.lean`: source of the base literals.
3. `ShannonBounds/PortRealisation.lean`: source of the seven-family separation system.
4. `ShannonBounds/Layered.lean`: existing substitution and multilinear lifting mechanism.
5. `ShannonBounds/Substitutions.lean`: source of T2b, T3c, T3d and the existing library.
6. `ShannonBounds/TerminalCodes.lean`: source of K3a.
7. `ShannonBounds/CertC11.lean`: source of the exact dimension-207 baseline and schedule.
8. Ravi Tandon, *Strengthening Recursive Constructions for Zero-Error Shannon Capacity*, arXiv:2608.30273v1, especially Remark 3: https://arxiv.org/html/2608.30273v1

The construction belongs to the Gao / Itty et al. / BPZ line of work. The contribution isolated in this package is the explicit coordinated auxiliary trade at x27 and its exact improvement of the frozen certificate.
