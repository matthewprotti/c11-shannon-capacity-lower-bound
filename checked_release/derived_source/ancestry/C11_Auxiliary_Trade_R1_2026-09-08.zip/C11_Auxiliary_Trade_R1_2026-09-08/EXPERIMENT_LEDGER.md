# Bounded exploration ledger

All activity occurred in the current 8 September 2026 session. No task remains running.

## Source access and baseline

The relevant repository files were read using the GitHub connector at the supplied full commit. A local git clone failed because the sandbox could not resolve github.com. Raw-download attempts also failed. Literal numerical data and tables were transcribed from the connector responses, with this extraction boundary recorded in the frozen data. A NumPy-based exploratory implementation reproduced the exact baseline integer and the first nontrivial g3 profile. A separate standard-library implementation later reconstructed the graph tests and both full certificates.

## Orbit experiment — complete in the stated class

For each of the supplied I and X seeds, enumerated 6 coordinate permutations, 8 sign choices, and 11^3 translations, holding the original I and its three selected private pairs fixed in the auxiliary test. There were 127,776 labelled images; duplicate images were not quotiented. Three passed the required no-double-footprint condition. All three had profile `(145,142,3,3,3,3,3)` and no uniform-baseline improvement. This does not classify all optimal seeds, all port choices, or all auxiliary independent sets.

The supplied I has six private-neighbor alternatives in total. Only the three published selected pairs were used by this orbit experiment.

## Six-dimensional point additions and small single-family exchanges

Expanded the seven families at b2 exactly, in the physical universe of 11^6=1,771,561 words. For each output family, used actual coordinate conflicts, not a count-only substitute.

No one-point addition preserves all constraints in any of B,N,A,D,H,V with the other families fixed. O has 14,433 individually admissible vertices, but O is unused by every later table in the fixed schedule, so increasing O alone cannot change the final cardinality.

For each of the six used families, enumerated outside words allowed by the fixed other families that have at most two blockers in the current family. There were no one-blocker candidates. The grouping/triple search found no 1-to-2 or 2-to-3 single-family cardinality improvement. These results do not exclude larger exchanges or coupled changes to multiple families. The positive certificate does not depend on these negative search results.

## Role-weighted base-auxiliary MILP — not an exact closure proof

Computed exact terminal derivatives for the 69 unfolded base occurrences. Searched X replacements retaining at least 136 of the supplied 148 auxiliary words. Search used numerical objective coefficients in SciPy/HiGHS; proposed witnesses were checked with integers.

The planned leaves were 0,28,49,55, with 30 seconds requested per solver call. Leaves 0 and 28 returned the original X and reported numerical optimality. During the third call, the enclosing 150-second execution watchdog terminated the process before it returned or the final leaf was run. No process was left running. The two completed records are preserved; the interrupted third query is undecided. The solver's two numerical optimality reports are **not** exact infeasibility or optimality certificates and are not used as mathematical conclusions.

## Positive coordinated table trade — stopped at first witness

The role-weighted table search examined the first nonterminal node x27. Candidate inputs retained the full abstract separation relation, which is itself independently realized by the literal base sets; missing separation edges were never inferred from cardinalities. A coordinated 3-tag removal / 2-tag insertion gave a strict exact increase. The new table was checked for all required within-family and cross-family separations, and the complete integer was replayed.

The initial heuristic scores used floating-point normalized derivatives to locate a trade, but acceptance used exact integer gains and full table admissibility. The separately implemented final verifier uses no floating point. The frozen candidate is the first positive witness; no further optimization was performed after it was found.

## Scope of remaining work

No full Lean build, independent external review, or complete priority clearance has been performed. No claim is made that any failed local search proves a general obstruction. No general two-sided heterogeneous extension has been proved.
