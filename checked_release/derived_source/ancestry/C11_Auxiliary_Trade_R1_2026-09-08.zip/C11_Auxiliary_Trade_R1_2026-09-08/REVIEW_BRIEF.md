# Narrow adversarial review brief

## The claim to attack

The literal code and table construction in this package gives an independent set of size N1 in C11^207, with N1 greater than N0 from BPZ commit `aa21eeb12b75b0413d3fa9fb4208b5d0bf2c4d65`. Therefore it gives the lower bound 5.295492477500681.

Do not substitute a weaker decimal-only comparison, and do not assess a claimed general two-sided theorem: none is claimed.

## Mandatory first checks

Run `python3 -B VERIFY.py --self-test`. Compare the pinned upstream `BaseC11Data.lean`, `PortRealisation.lean`, `Substitutions.lean`, `TerminalCodes.lean`, and `CertC11.lean` with the literal data. Confirm the source encoding and the physical dimension 3*(27+29+13)=207.

Independently examine the lifting proof, in particular disjointness of products within one output family. The seven realized sets need not be pairwise disjoint globally. Equality counts as a conflict in separation tests.

Check the two new tagged words against the full old table. The required blocker lists must be exactly `{N:ADA,N:HHA}` and `{N:ADA,A:NDA}`. Check mutual separation of the two inserted words.

Then reconstruct the candidate integer with x27 alone changed. Independently verify the positive factorization in PROOF.md and the exact decimal bracket.

## Explicit unresolved review obligations

The included Lean fragment has not been built. Promote it through the pinned BPZ multilinear construction and capacity definitions; do not label the new bound formally verified until the complete theorem builds and its axioms are checked.

Check newer commits, author repositories, arXiv revisions, and relevant public records for a stronger C11 certificate or an already published equivalent hybrid. Absence from a quick search is not priority clearance. The row hybrid is deliberately credited to the existing T3c/T3d library, not advertised as a new general mechanism.

Distinguish mathematical correctness, priority, and significance. A passed exact comparison establishes the first narrow numerical target, not a guaranteed VibeMathed rating.

Return one of: REJECT_WITH_WITNESS; CORRECT_FINITE_CERTIFICATE_WITH_REMAINING_FORMAL_OR_PRIORITY_GATES; or FULL_REVIEW_PASS_WITH_EXPLICIT_SCOPE. Include commands, environment, upstream commit, and exact errors or supporting identities.
