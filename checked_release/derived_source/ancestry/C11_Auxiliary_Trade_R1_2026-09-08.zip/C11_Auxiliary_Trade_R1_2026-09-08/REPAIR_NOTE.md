# C11 R1: acceptance of finite result and repair of F3

Date: 8 September 2026.

## Disposition

Accept the supplied review's narrow mathematical conclusion: the unchanged finite construction yields an independent set of size N1 in the 207th strong power of C11, strictly exceeding the pinned BPZ integer N0. Therefore it proves the advertised capacity lower bound 5.295492477500681.

This disposition rests on the received automated adversarial review and its separately written reconstruction, including the lifting/disjointness argument. It is not a human referee report, a new independent review of this repair, a completed Lean build, or worldwide priority clearance.

The original checkpoint SHA-256 is:

```text
b62863f7cd1718024a94a52683dd2fd2e95725bc9531832d8b37585450fb5b66
```

The received review ZIP SHA-256 is:

```text
e983a2235be05eca8230eee2b2b951903c2cd605c1510efcb3fabe27ee7c0520
```

Both archives are bundled unchanged under `ancestry/`.

## What was reproduced

The original manifest and received review manifest both pass. The unchanged `INDEPENDENT_REVIEW.py` was rerun against the original ZIP normally and with Python optimization, in each case with `--expand-b2`. The two output reports are byte-identical.

The reconstruction agrees on N0, N1, the exact gain, the physical dimension, the positive factorization, and the strict root bracket. The direct six-dimensional audit checks all seven b2 families and their required cross separations; it records 317,348 nonempty first-block queries. This does not enumerate the enormous final independent set; the Cartesian-product induction supplies that step.

The review's eight-hybrid comparison also reproduces: six are admissible, and only the N+A row hybrid improves the frozen baseline. This is a complete result for those eight choices at x27 with everything else fixed, not an obstruction theorem for other tables, nodes, schedules, or seeds.

## F3: exact defect and repair

The reported in-memory mutation was reproduced against the original verifier:

```python
cert['schema'] = 'NOT_A_REAL_SCHEMA'
cert['removed'] = []
cert['added'] = []
```

The original `VERIFY.run` accepted it. Its actual mathematical table-difference checks still ran and were correct, so this was inconsistent descriptive metadata, not a false mathematical acceptance. An altered on-disk candidate would also disagree with the original manifest.

R1 now checks the exact expected schema identifier `C11_AUXILIARY_TRADE_CERTIFICATE_V1` and requires:

```text
set(declared removed tags) = original table tags - replacement table tags
set(declared added tags)   = replacement table tags - original table tags
```

The original fixed-trade checks remain in place as separate obligations. The descriptive fields must be lists of valid [output family, three-letter word] pairs. Missing fields, malformed types, duplicate tags, invalid symbols, wrong lengths, extra entries, and mismatches are explicitly rejected. List order is deliberately irrelevant. This is targeted validation of the schema identifier and trade metadata, not a claim of exhaustive validation of every free-text or provenance field.

No certificate-format change was needed: the original certificate is valid and remains byte-for-byte unchanged. The expected schema stays V1; R1 identifies the verifier/release revision.

## Tests of the repair

Both normal and optimized execution reject all 30 verifier negative controls: the original six and 24 added metadata regressions. These test schema and tag defects separately as well as in the reported combination. A positive control reverses the added/removed lists and accepts the same exact result.

The supplied `ADDITIONAL_MUTATIONS.py`, unchanged, was also run against R1 in normal and optimized modes. All ten cases are now rejected by explicit `CheckFailed` validation; previously the combined F3 case was accepted. These ten cases overlap the built-in controls and are not claimed to be ten additional distinct attack classes.

The resulting reports agree between normal and optimized modes. Final sealed replay includes a complete manifest check, original/review digest checks, unchanged mathematical input checks, and a fresh independent parent replay. Fresh-extraction and non-mutating replay checks are recorded in the externally sealed validation summary accompanying the ZIP.

## What has not changed

`CANDIDATE.json`, `FROZEN_INPUTS.json`, `PROOF.md`, and `CandidateTrade.lean` are byte-identical to the original checkpoint. The original experiment ledger and exploration files are preserved, not rerun. The proof remains the same construction, in the same dimension, at the same cardinality and exact root bound. R1 is not a second discovery or a stronger numerical candidate.

The old proof/certificate texts retain their original review-status wording as historical evidence. `README.md` and `RELEASE_STATUS.json` record the updated disposition explicitly; stored original review outputs have not been overwritten to manufacture a different historical outcome.

## Next gate

Complete end-to-end Lean integration of this unchanged candidate through the actual independent-set and capacity interfaces, not just a build of the fragment's integer inequalities. `LEAN_INTEGRATION_BRIEF.md` specifies the frozen scope. No Lean build was performed for R1; no Lean/lake/elan executable was found on PATH in this run.

The worldwide-priority and significance questions remain separate. No new literature scan was performed in this repair turn, and the review does not establish a guaranteed VibeMathed score or solve Tandon's general two-sided extension.
